CREATE DATABASE IF NOT EXISTS employee_payroll;
USE employee_payroll;

CREATE TABLE IF NOT EXISTS users(
 id INT PRIMARY KEY AUTO_INCREMENT,
 username VARCHAR(50) NOT NULL UNIQUE,
 password VARCHAR(50) NOT NULL
);

DELETE FROM users;

INSERT INTO users(username,password) VALUES
('admin','admin123'),
('employee1','emp123');

CREATE TABLE IF NOT EXISTS employees(
 emp_id INT PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(100),
 gender VARCHAR(20),
 email VARCHAR(100),
 mobile VARCHAR(15),
 department VARCHAR(50),
 designation VARCHAR(50),
 basic_salary DOUBLE,
 joining_date DATE,
 username VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS attendance(
 attendance_id INT PRIMARY KEY AUTO_INCREMENT,
 emp_id INT,
 attendance_date DATE,
 status VARCHAR(20),
 FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
);

CREATE TABLE IF NOT EXISTS leave_details(
 leave_id INT PRIMARY KEY AUTO_INCREMENT,
 emp_id INT,
 leave_type VARCHAR(30),
 from_date DATE,
 to_date DATE,
 reason VARCHAR(200),
 status VARCHAR(30),
 FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
);

CREATE TABLE IF NOT EXISTS salary(
 salary_id INT PRIMARY KEY AUTO_INCREMENT,
 emp_id INT,
 month VARCHAR(20),
 basic DOUBLE,
 hra DOUBLE,
 da_amount DOUBLE,
 pf DOUBLE,
 tax DOUBLE,
 net_salary DOUBLE,
 FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
);

INSERT INTO employees(name,gender,email,mobile,department,designation,basic_salary,joining_date,username)
SELECT 'Rahul Sharma','Male','rahul@gmail.com','9876543210','IT','Software Engineer',45000,'2026-01-15','employee1'
WHERE NOT EXISTS (SELECT 1 FROM employees WHERE username='employee1');
