package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.LoginDAO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID=1L;

    protected void doPost(HttpServletRequest request,HttpServletResponse response)
            throws ServletException,IOException {
        String username=request.getParameter("username");
        String password=request.getParameter("password");

        if(new LoginDAO().validate(username,password)) {
            HttpSession session=request.getSession();
            session.setAttribute("username",username);
            session.setAttribute("role","admin".equals(username) ? "admin" : "employee");
            response.sendRedirect(request.getContextPath()+"/dashboard.jsp");
        } else {
            response.sendRedirect(request.getContextPath()+"/login.jsp?error=1");
        }
    }

    protected void doGet(HttpServletRequest request,HttpServletResponse response)
            throws ServletException,IOException {
        response.sendRedirect(request.getContextPath()+"/login.jsp");
    }
}
