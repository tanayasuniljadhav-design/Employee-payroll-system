MAJOR PROJECT - EMPLOYEE MANAGEMENT PORTAL

Project: major_project
Technology: JSP, Servlet, JDBC, MySQL, Tomcat 9

LOGIN:
Admin    -> admin / admin123
Employee -> employee1 / emp123

1. Import this folder into Eclipse as an existing project.
2. Add Apache Tomcat 9 as Targeted Runtime.
3. Add MySQL Connector/J JAR to WebContent/WEB-INF/lib.
4. Start MySQL/XAMPP. Default port in DBConnection.java is 3306.
5. Run Database/employee_payroll.sql in phpMyAdmin.
6. Add the project to Tomcat using Servers -> Add and Remove.
7. Start Tomcat.
8. Open:
   http://localhost:8080/major_project/

If MySQL uses port 3307 or 3309, change DBConnection.java URL.

IMPORTANT:
This package intentionally contains a simple login/dashboard first so the deployment can be tested before adding the full payroll modules.
