<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
if(session.getAttribute("username")==null){response.sendRedirect("login.jsp");return;}
String username=(String)session.getAttribute("username");
%>
<!DOCTYPE html><html><head><title>My Profile</title><style>body{font-family:Arial;background:#eef5ff;padding:40px}.box{max-width:700px;margin:auto;background:#fff;padding:35px;border-radius:18px;box-shadow:0 8px 25px #ccd}a{display:inline-block;margin-top:20px;padding:12px 20px;background:#1769c2;color:white;text-decoration:none;border-radius:8px}</style></head><body><div class="box"><h1>👤 My Profile</h1><p><b>Username:</b> <%=username%></p><p>This employee profile page is ready for your employee table data.</p><a href="dashboard.jsp">Back to Dashboard</a></div></body></html>
