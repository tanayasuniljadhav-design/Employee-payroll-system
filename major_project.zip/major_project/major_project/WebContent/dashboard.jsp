<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
String username=(String)session.getAttribute("username");
String role=(String)session.getAttribute("role");
if(username==null){response.sendRedirect("login.jsp");return;}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial;background:#f4f7fb}.side{position:fixed;left:0;top:0;width:240px;height:100vh;background:linear-gradient(180deg,#141e30,#243b55);color:#fff;padding:25px 15px}.logo{text-align:center;font-size:21px;font-weight:bold;margin-bottom:30px}.side a{display:block;color:#fff;text-decoration:none;padding:13px;margin:7px 0;border-radius:8px}.side a:hover{background:#1769c2}.logout{background:#d63031}.main{margin-left:240px;padding:30px}.top{background:#fff;padding:20px;border-radius:15px;display:flex;justify-content:space-between;box-shadow:0 4px 15px rgba(0,0,0,.08);margin-bottom:25px}.role{padding:8px 14px;border-radius:20px;background:#1769c2;color:#fff}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:20px}.card{padding:25px;border-radius:15px;color:#fff;min-height:130px;box-shadow:0 5px 15px rgba(0,0,0,.15)}.c1{background:linear-gradient(135deg,#667eea,#764ba2)}.c2{background:linear-gradient(135deg,#11998e,#38ef7d)}.c3{background:linear-gradient(135deg,#ff9966,#ff5e62)}.c4{background:linear-gradient(135deg,#396afc,#2948ff)}.info{margin-top:30px;background:#fff;padding:25px;border-radius:15px}
</style>
</head>
<body>
<div class="side">
<div class="logo">👨‍💼 Payroll System</div>
<a href="dashboard.jsp">🏠 Dashboard</a>
<% if("admin".equals(role)){ %>
<a href="#">👥 Employee Management</a>
<a href="#">💰 Salary Management</a>
<a href="#">📅 Attendance Management</a>
<a href="#">📝 Leave Management</a>
<a href="#">📊 Reports</a>
<% } else { %>
<a href="employeeProfile.jsp">👤 My Profile</a>
<a href="employeeSalary.jsp">💰 My Salary</a>
<a href="employeeAttendance.jsp">📅 My Attendance</a>
<a href="employeeLeave.jsp">📝 My Leave</a>
<% } %>
<a class="logout" href="LogoutServlet">🚪 Logout</a>
</div>
<div class="main">
<div class="top"><div><h2 style="margin:0">Welcome, <%=username%> 👋</h2><p style="margin:6px 0 0;color:#718096">Employee Management Portal</p></div><div class="role"><%=role.toUpperCase()%></div></div>
<div class="cards">
<div class="card c1"><h2>👤</h2><b><%= "admin".equals(role) ? "Employees" : "My Profile" %></b></div>
<div class="card c2"><h2>💰</h2><b><%= "admin".equals(role) ? "Salary" : "My Salary" %></b></div>
<div class="card c3"><h2>📅</h2><b><%= "admin".equals(role) ? "Attendance" : "My Attendance" %></b></div>
<div class="card c4"><h2>📝</h2><b><%= "admin".equals(role) ? "Leave & Reports" : "My Leave" %></b></div>
</div>
<div class="info">
<h2><%= "admin".equals(role) ? "Admin Dashboard" : "Employee Dashboard" %></h2>
<p><%= "admin".equals(role) ? "You are logged in as administrator. Employee, salary, attendance, leave and report modules are available." : "You are logged in as an employee. You can access your profile and employee information." %></p>
</div>
</div>
</body>
</html>
