<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Employee Management Portal</title>
<style>
*{box-sizing:border-box} body{margin:0;min-height:100vh;font-family:Arial,sans-serif;background:linear-gradient(135deg,#d9efff,#f5f9ff,#cfe5ff);display:flex;justify-content:center;align-items:center}
.box{width:420px;background:#fff;border-radius:20px;padding:40px;box-shadow:0 15px 40px rgba(0,60,130,.2);text-align:center}
.logo{width:65px;height:65px;margin:auto;background:#1769c2;color:#fff;border-radius:15px;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:bold}
h1{color:#1256a3;margin:15px 0 5px}.sub{color:#7890a5;margin-bottom:30px}
input{width:100%;padding:14px;margin:10px 0;border:1px solid #d5dce5;border-radius:9px;font-size:15px}
button{width:100%;padding:14px;margin-top:15px;border:0;border-radius:9px;background:#1769c2;color:#fff;font-size:16px;font-weight:bold;cursor:pointer}
button:hover{background:#0d4f9a}.error{margin-top:15px;color:#d63031;font-weight:bold}.demo{margin-top:25px;padding:15px;background:#f2f7fc;border-radius:10px;font-size:13px;color:#536878}
</style>
</head>
<body>
<div class="box">
<div class="logo">AP</div>
<h1>Accenture plc</h1>
<div class="sub">Employee Management Portal</div>
<form action="LoginServlet" method="post">
<input type="text" name="username" placeholder="Enter username" required>
<input type="password" name="password" placeholder="Enter password" required>
<button type="submit">Login</button>
</form>
<% if ("1".equals(request.getParameter("error"))) { %>
<div class="error">Invalid username or password.</div>
<% } else if ("2".equals(request.getParameter("error"))) { %>
<div class="error">Server/database error. Check Eclipse Console.</div>
<% } %>
<div class="demo">
<b>Admin</b><br>admin / admin123<br><br>
<b>Employee</b><br>employee1 / emp123
</div>
</div>
</body>
</html>
