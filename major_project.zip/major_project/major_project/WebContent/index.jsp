<%
response.sendRedirect("login.jsp");
%>
