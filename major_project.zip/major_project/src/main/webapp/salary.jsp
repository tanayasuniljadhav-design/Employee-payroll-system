<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Salary Generation - Employee Management Portal</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    min-height: 100vh;

    background:
        radial-gradient(circle at 10% 20%, rgba(66,165,245,0.30), transparent 30%),
        radial-gradient(circle at 90% 80%, rgba(30,136,229,0.30), transparent 30%),
        linear-gradient(135deg, #061b45, #0d47a1, #1976d2);

    padding: 30px 15px;
    color: #263238;
}

/* Header */

.header {
    max-width: 850px;
    margin: 0 auto 25px auto;

    background: linear-gradient(135deg, #0b3d91, #1565c0);

    color: white;

    padding: 20px 25px;

    border-radius: 15px;

    box-shadow: 0 8px 25px rgba(0,0,0,0.25);

    display: flex;
    justify-content: space-between;
    align-items: center;
}

.brand {
    display: flex;
    align-items: center;
    gap: 14px;
}

.logo {
    width: 52px;
    height: 52px;

    background: white;
    color: #0d47a1;

    border-radius: 12px;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 20px;
    font-weight: bold;
}

.brand h1 {
    font-size: 21px;
}

.brand p {
    font-size: 12px;
    margin-top: 4px;
    opacity: 0.85;
}

.dashboard-btn {
    color: white;
    text-decoration: none;

    padding: 10px 16px;

    border: 1px solid rgba(255,255,255,0.5);

    border-radius: 8px;

    font-size: 14px;

    transition: 0.3s;
}

.dashboard-btn:hover {
    background: white;
    color: #0d47a1;
}

/* Main Card */

.container {
    max-width: 650px;
    margin: auto;

    background: rgba(255,255,255,0.97);

    padding: 35px;

    border-radius: 18px;

    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}

/* Title */

.title-section {
    text-align: center;

    margin-bottom: 30px;
}

.title-icon {
    width: 70px;
    height: 70px;

    margin: 0 auto 15px auto;

    background: #e3f2fd;
    color: #1565c0;

    border-radius: 50%;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 30px;
}

.title-section h2 {
    color: #0d47a1;

    font-size: 27px;

    margin-bottom: 7px;
}

.title-section p {
    color: #78909c;

    font-size: 13px;
}

/* Form */

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;

    color: #37474f;

    font-size: 14px;

    font-weight: bold;

    margin-bottom: 7px;
}

.required {
    color: #e53935;
}

.input-wrapper {
    position: relative;
}

.input-icon {
    position: absolute;

    left: 13px;
    top: 50%;

    transform: translateY(-50%);

    color: #78909c;

    font-size: 16px;
}

input {
    width: 100%;

    padding: 13px 42px;

    border: 1px solid #cfd8dc;

    border-radius: 9px;

    background: #f8fbff;

    font-size: 14px;

    outline: none;

    transition: 0.3s;
}

input:focus {
    border-color: #1976d2;

    background: white;

    box-shadow:
        0 0 0 3px rgba(25,118,210,0.12);
}

/* Generate Button */

.button-group {
    display: flex;

    gap: 12px;

    margin-top: 25px;
}

button {
    flex: 1;

    padding: 14px;

    border: none;

    border-radius: 9px;

    font-size: 15px;

    font-weight: bold;

    cursor: pointer;

    transition: 0.3s;
}

.generate-btn {
    background: linear-gradient(135deg, #0d47a1, #1976d2);

    color: white;
}

.generate-btn:hover {
    transform: translateY(-2px);

    box-shadow:
        0 10px 22px rgba(13,71,161,0.35);
}

.clear-btn {
    background: #eceff1;

    color: #37474f;
}

.clear-btn:hover {
    background: #cfd8dc;
}

/* Information Box */

.info-box {
    margin-top: 25px;

    padding: 15px;

    background: #e3f2fd;

    border-left: 4px solid #1976d2;

    border-radius: 7px;

    color: #455a64;

    font-size: 12px;

    line-height: 1.6;
}

/* Loading */

.generate-btn.loading {
    opacity: 0.75;

    cursor: wait;
}

/* Responsive */

@media (max-width: 600px) {

    .header {
        flex-direction: column;

        gap: 15px;

        text-align: center;
    }

    .brand {
        flex-direction: column;
    }

    .container {
        padding: 25px 20px;
    }

    .button-group {
        flex-direction: column;
    }

}

</style>

<script>

/* Salary Form Validation */

function validateSalaryForm() {

    var empId =
        document.getElementById("empId").value;

    var month =
        document.getElementById("month").value.trim();

    var basic =
        parseFloat(document.getElementById("basic").value);


    if (empId === "" || parseInt(empId) <= 0) {

        alert("Please enter a valid Employee ID.");

        return false;
    }


    if (month === "") {

        alert("Please enter the salary month.");

        return false;
    }


    if (isNaN(basic) || basic <= 0) {

        alert("Please enter a valid Basic Salary.");

        return false;
    }


    return confirm(
        "Are you sure you want to generate salary for Employee ID "
        + empId + "?"
    );
}


/* Clear Form */

function clearSalaryForm() {

    document.getElementById("salaryForm").reset();

}


/* Generate Button Loading */

function showLoading() {

    if (!validateSalaryForm()) {
        return false;
    }

    var button =
        document.getElementById("generateButton");

    button.innerHTML = "Generating Salary...";

    button.classList.add("loading");

    button.disabled = true;

    return true;
}

</script>

</head>


<body>


<!-- Header -->

<div class="header">

    <div class="brand">

        <div class="logo">
            AP
        </div>

        <div>

            <h1>Accenture plc</h1>

            <p>
                Employee Management Portal
            </p>

        </div>

    </div>


    <a href="dashboard.jsp"
       class="dashboard-btn">

        ← Dashboard

    </a>

</div>


<!-- Salary Form -->

<div class="container">


    <div class="title-section">

        <div class="title-icon">
            💰
        </div>

        <h2>
            Generate Salary
        </h2>

        <p>
            Generate monthly payroll for an employee
        </p>

    </div>


    <form id="salaryForm"
          action="SalaryServlet"
          method="post"
          onsubmit="return showLoading()">


        <!-- Employee ID -->

        <div class="form-group">

            <label for="empId">
                Employee ID <span class="required">*</span>
            </label>

            <div class="input-wrapper">

                <span class="input-icon">
                    👤
                </span>

                <input
                    type="number"
                    id="empId"
                    name="empId"
                    placeholder="Enter Employee ID"
                    min="1"
                    required>

            </div>

        </div>


        <!-- Month -->

        <div class="form-group">

            <label for="month">
                Salary Month <span class="required">*</span>
            </label>

            <div class="input-wrapper">

                <span class="input-icon">
                    📅
                </span>

                <input
                    type="text"
                    id="month"
                    name="month"
                    placeholder="Example: October 2026"
                    required>

            </div>

        </div>


        <!-- Basic Salary -->

        <div class="form-group">

            <label for="basic">
                Basic Salary <span class="required">*</span>
            </label>

            <div class="input-wrapper">

                <span class="input-icon">
                    ₹
                </span>

                <input
                    type="number"
                    id="basic"
                    name="basic"
                    step="0.01"
                    min="0.01"
                    placeholder="Enter Basic Salary"
                    required>

            </div>

        </div>


        <!-- Buttons -->

        <div class="button-group">

            <button
                type="button"
                class="clear-btn"
                onclick="clearSalaryForm()">

                Clear

            </button>


            <button
                type="submit"
                id="generateButton"
                class="generate-btn">

                Generate Salary

            </button>

        </div>


    </form>


    <!-- Information -->

    <div class="info-box">

        <strong>Payroll Information:</strong><br>

        Enter the employee ID, salary month and basic salary
        carefully before generating the payroll record.

    </div>


</div>


</body>

</html>