<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Employee" %>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>View Employees | Accenture Employee Management</title>

<style>

/* =========================================================
   GLOBAL
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:"Segoe UI",Arial,Helvetica,sans-serif;
    background:linear-gradient(
        135deg,
        #e3f2fd,
        #f5f9ff,
        #dbeafe
    );
    min-height:100vh;
    color:#263238;
}


/* =========================================================
   HEADER
========================================================= */

.header{
    background:linear-gradient(
        135deg,
        #0d47a1,
        #1565c0,
        #1976d2
    );

    color:white;

    min-height:75px;

    padding:0 35px;

    display:flex;

    align-items:center;

    justify-content:space-between;

    box-shadow:
        0 5px 18px rgba(13,71,161,0.25);
}

.logo-section{
    display:flex;
    align-items:center;
    gap:14px;
}

.logo{
    width:45px;
    height:45px;

    background:white;

    color:#1565c0;

    border-radius:10px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-weight:800;

    font-size:19px;
}

.company-name{
    font-size:20px;
    font-weight:700;
}

.portal-name{
    font-size:12px;
    opacity:0.85;
}

.header-right{
    font-size:14px;
}


/* =========================================================
   MAIN CONTAINER
========================================================= */

.container{
    width:94%;
    max-width:1500px;

    margin:30px auto;
}


/* =========================================================
   PAGE TOP
========================================================= */

.page-top{
    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-bottom:25px;

    gap:20px;
}

.page-title h1{
    color:#0d47a1;

    font-size:30px;

    margin-bottom:4px;
}

.page-title p{
    color:#607d8b;

    font-size:14px;
}


/* =========================================================
   TOP BUTTONS
========================================================= */

.top-actions{
    display:flex;

    gap:10px;

    flex-wrap:wrap;
}

.add{
    display:inline-block;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #0d47a1
        );

    color:white;

    padding:12px 19px;

    border-radius:9px;

    text-decoration:none;

    font-size:14px;

    font-weight:600;

    box-shadow:
        0 5px 12px rgba(21,101,192,0.25);

    transition:0.25s;
}

.add:hover{
    color:white;

    transform:translateY(-2px);

    box-shadow:
        0 8px 18px rgba(21,101,192,0.32);
}

.dashboard{
    display:inline-block;

    background:white;

    color:#1565c0;

    border:1px solid #1565c0;

    padding:11px 18px;

    border-radius:9px;

    text-decoration:none;

    font-size:14px;

    font-weight:600;

    transition:0.25s;
}

.dashboard:hover{
    background:#e3f2fd;

    color:#0d47a1;
}


/* =========================================================
   SUMMARY CARDS
========================================================= */

.summary{
    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:20px;

    margin-bottom:25px;
}

.summary-card{
    background:rgba(255,255,255,0.96);

    padding:20px;

    border-radius:15px;

    display:flex;

    align-items:center;

    gap:15px;

    border-left:5px solid #1565c0;

    box-shadow:
        0 7px 22px rgba(21,101,192,0.12);

    transition:0.25s;
}

.summary-card:hover{
    transform:translateY(-3px);

    box-shadow:
        0 11px 28px rgba(21,101,192,0.18);
}

.summary-icon{
    width:50px;
    height:50px;

    border-radius:12px;

    background:#e3f2fd;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:23px;
}

.summary-card h4{
    color:#607d8b;

    font-size:12px;

    margin-bottom:3px;
}

.summary-card h2{
    color:#0d47a1;

    font-size:23px;
}


/* =========================================================
   EMPLOYEE CARD
========================================================= */

.employee-card{
    background:rgba(255,255,255,0.97);

    border-radius:16px;

    padding:25px;

    box-shadow:
        0 10px 30px rgba(13,71,161,0.13);
}


/* =========================================================
   TOOLBAR
========================================================= */

.toolbar{
    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:15px;

    margin-bottom:20px;

    flex-wrap:wrap;
}

.search-box{
    position:relative;

    flex:1;

    min-width:250px;
}

.search-box input{
    width:100%;

    padding:13px 15px 13px 43px;

    border:1px solid #cfd8e3;

    border-radius:9px;

    background:#f8fbff;

    outline:none;

    font-family:inherit;

    font-size:14px;
}

.search-box input:focus{
    border-color:#1976d2;

    background:white;

    box-shadow:
        0 0 0 3px rgba(25,118,210,0.12);
}

.search-icon{
    position:absolute;

    left:14px;

    top:10px;

    font-size:18px;
}

.clear-btn{
    border:none;

    background:#eceff1;

    color:#37474f;

    padding:12px 18px;

    border-radius:8px;

    cursor:pointer;

    font-weight:600;

    font-family:inherit;
}

.clear-btn:hover{
    background:#cfd8dc;
}


/* =========================================================
   TABLE
========================================================= */

.table-wrapper{
    width:100%;

    overflow-x:auto;

    border-radius:12px;

    border:1px solid #e0e7ef;
}

table{
    width:100%;

    min-width:1200px;

    border-collapse:collapse;

    background:white;
}

th{
    background:
        linear-gradient(
            135deg,
            #0d47a1,
            #1565c0
        );

    color:white;

    padding:14px 12px;

    font-size:13px;

    text-align:center;

    white-space:nowrap;
}

td{
    padding:13px 11px;

    text-align:center;

    font-size:13px;

    color:#455a64;

    border-bottom:1px solid #e8edf3;

    white-space:nowrap;
}

tbody tr{
    transition:0.2s;
}

tbody tr:hover{
    background:#f1f7ff;
}


/* =========================================================
   EMPLOYEE ID
========================================================= */

.employee-id{
    font-weight:700;

    color:#1565c0;

    background:#e3f2fd;

    padding:5px 9px;

    border-radius:6px;
}


/* =========================================================
   SALARY
========================================================= */

.salary{
    color:#0b7a42;

    font-weight:700;
}


/* =========================================================
   DEPARTMENT
========================================================= */

.department{
    color:#1565c0;

    font-weight:600;
}


/* =========================================================
   DESIGNATION
========================================================= */

.designation{
    font-weight:600;

    color:#455a64;
}


/* =========================================================
   ACTION BUTTONS
========================================================= */

.edit,
.delete{
    display:inline-block;

    text-decoration:none;

    padding:7px 12px;

    border-radius:7px;

    font-size:12px;

    font-weight:600;

    transition:0.2s;
}

.edit{
    background:#e8f5e9;

    color:#2e7d32;

    border:1px solid #a5d6a7;
}

.edit:hover{
    background:#2e7d32;

    color:white;
}

.delete{
    background:#ffebee;

    color:#c62828;

    border:1px solid #ef9a9a;
}

.delete:hover{
    background:#c62828;

    color:white;
}


/* =========================================================
   NO DATA
========================================================= */

.no-data{
    text-align:center;

    padding:45px;

    color:#78909c;

    font-size:15px;
}

.no-data-icon{
    font-size:42px;

    margin-bottom:10px;
}


/* =========================================================
   FOOTER
========================================================= */

.footer{
    text-align:center;

    margin-top:25px;

    padding:15px;

    color:#607d8b;

    font-size:12px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:900px){

    .summary{
        grid-template-columns:1fr;
    }

    .page-top{
        flex-direction:column;

        align-items:flex-start;
    }

    .header-right{
        display:none;
    }

    .header{
        padding:0 18px;
    }

    .container{
        width:96%;
    }
}


@media(max-width:600px){

    .company-name{
        font-size:16px;
    }

    .portal-name{
        font-size:10px;
    }

    .page-title h1{
        font-size:24px;
    }

    .top-actions{
        width:100%;
    }

    .add,
    .dashboard{
        flex:1;

        text-align:center;
    }

    .employee-card{
        padding:15px;
    }

    .toolbar{
        flex-direction:column;

        align-items:stretch;
    }

    .search-box{
        min-width:100%;
    }

    .clear-btn{
        width:100%;
    }
}

</style>

</head>


<body>


<!-- =====================================================
     HEADER
===================================================== -->

<div class="header">

    <div class="logo-section">

        <div class="logo">
            AP
        </div>

        <div>

            <div class="company-name">
                Accenture plc
            </div>

            <div class="portal-name">
                Employee Management Portal
            </div>

        </div>

    </div>

    <div class="header-right">
        👥 Employee Administration
    </div>

</div>


<!-- =====================================================
     MAIN CONTAINER
===================================================== -->

<div class="container">


    <!-- PAGE TITLE -->

    <div class="page-top">

        <div class="page-title">

            <h1>Employee Management</h1>

            <p>
                View, manage and maintain employee records
            </p>

        </div>


        <div class="top-actions">

            <a href="dashboard.jsp"
               class="dashboard">
                ← Dashboard
            </a>

            <a href="addEmployee.jsp"
               class="add">
                + Add Employee
            </a>

        </div>

    </div>


    <!-- =================================================
         SUMMARY
    ================================================= -->

    <div class="summary">

        <div class="summary-card">

            <div class="summary-icon">
                👥
            </div>

            <div>

                <h4>Total Employees</h4>

                <h2 id="totalEmployees">
                    0
                </h2>

            </div>

        </div>


        <div class="summary-card">

            <div class="summary-icon">
                🏢
            </div>

            <div>

                <h4>Departments</h4>

                <h2 id="totalDepartments">
                    0
                </h2>

            </div>

        </div>


        <div class="summary-card">

            <div class="summary-icon">
                💼
            </div>

            <div>

                <h4>Active Records</h4>

                <h2 id="activeRecords">
                    0
                </h2>

            </div>

        </div>

    </div>


    <!-- =================================================
         EMPLOYEE TABLE CARD
    ================================================= -->

    <div class="employee-card">


        <!-- TOOLBAR -->

        <div class="toolbar">

            <div class="search-box">

                <span class="search-icon">
                    🔍
                </span>

                <input
                    type="text"
                    id="employeeSearch"
                    placeholder="Search by name, ID, department, email..."
                    onkeyup="searchEmployees()">

            </div>


            <button
                type="button"
                class="clear-btn"
                onclick="clearSearch()">

                Clear Search

            </button>

        </div>


        <!-- =================================================
             EMPLOYEE TABLE
        ================================================= -->

        <div class="table-wrapper">

            <table id="employeeTable">

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Name</th>

                        <th>Gender</th>

                        <th>Email</th>

                        <th>Mobile</th>

                        <th>Department</th>

                        <th>Designation</th>

                        <th>Salary</th>

                        <th>Joining Date</th>

                        <th>Edit</th>

                        <th>Delete</th>

                    </tr>

                </thead>


                <tbody>

                <%

                ArrayList<Employee> list =
                (ArrayList<Employee>)request.getAttribute("list");

                if(list!=null && !list.isEmpty()){

                    for(Employee e:list){

                %>

                    <tr>


                        <!-- EMPLOYEE ID -->

                        <td>

                            <span class="employee-id">

                                EMP-<%=e.getEmpId()%>

                            </span>

                        </td>


                        <!-- NAME -->

                        <td>

                            <strong>
                                <%=e.getName()%>
                            </strong>

                        </td>


                        <!-- GENDER -->

                        <td>
                            <%=e.getGender()%>
                        </td>


                        <!-- EMAIL -->

                        <td>
                            <%=e.getEmail()%>
                        </td>


                        <!-- MOBILE -->

                        <td>
                            <%=e.getMobile()%>
                        </td>


                        <!-- DEPARTMENT -->

                        <td>

                            <span class="department">
                                <%=e.getDepartment()%>
                            </span>

                        </td>


                        <!-- DESIGNATION -->

                        <td>

                            <span class="designation">
                                <%=e.getDesignation()%>
                            </span>

                        </td>


                        <!-- SALARY -->

                        <td>

                            <span class="salary">

                                ₹<%=e.getBasicSalary()%>

                            </span>

                        </td>


                        <!-- JOINING DATE -->

                        <td>
                            <%=e.getJoiningDate()%>
                        </td>


                        <!-- EDIT -->

                        <td>

                            <a
                                class="edit"
                                href="editEmployee.jsp?id=<%=e.getEmpId()%>">

                                ✏ Edit

                            </a>

                        </td>


                        <!-- DELETE -->

                        <td>

                            <a
                                class="delete"
                                href="DeleteEmployeeServlet?id=<%=e.getEmpId()%>"
                                onclick="return confirmDelete('<%=e.getName()%>');">

                                🗑 Delete

                            </a>

                        </td>


                    </tr>

                <%

                    }

                }else{

                %>


                    <tr>

                        <td colspan="11">

                            <div class="no-data">

                                <div class="no-data-icon">
                                    👤
                                </div>

                                No employee records found.

                                <br><br>

                                <a
                                    href="addEmployee.jsp"
                                    class="add">

                                    + Add First Employee

                                </a>

                            </div>

                        </td>

                    </tr>


                <%

                }

                %>

                </tbody>

            </table>

        </div>

    </div>


    <!-- FOOTER -->

    <div class="footer">

        © 2026 Accenture plc
        • Employee Payroll & Management System

    </div>

</div>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script>


/* =========================================================
   SEARCH EMPLOYEES
========================================================= */

function searchEmployees(){

    var input =
        document.getElementById("employeeSearch")
        .value
        .toLowerCase()
        .trim();


    var rows =
        document.querySelectorAll(
            "#employeeTable tbody tr"
        );


    rows.forEach(function(row){

        var text =
            row.innerText.toLowerCase();


        if(text.includes(input)){

            row.style.display = "";

        }else{

            row.style.display = "none";

        }

    });


    updateEmployeeCount();

}


/* =========================================================
   CLEAR SEARCH
========================================================= */

function clearSearch(){

    document.getElementById(
        "employeeSearch"
    ).value = "";


    var rows =
        document.querySelectorAll(
            "#employeeTable tbody tr"
        );


    rows.forEach(function(row){

        row.style.display = "";

    });


    updateEmployeeCount();

}


/* =========================================================
   DELETE CONFIRMATION
========================================================= */

function confirmDelete(employeeName){

    return confirm(
        "Are you sure you want to delete employee \"" +
        employeeName +
        "\"?\n\nThis action cannot be undone."
    );

}


/* =========================================================
   UPDATE EMPLOYEE COUNT
========================================================= */

function updateEmployeeCount(){

    var rows =
        document.querySelectorAll(
            "#employeeTable tbody tr"
        );


    var visibleCount = 0;


    rows.forEach(function(row){

        if(
            row.children.length === 11 &&
            row.style.display !== "none"
        ){

            visibleCount++;

        }

    });


    document.getElementById(
        "totalEmployees"
    ).innerText = visibleCount;


    document.getElementById(
        "activeRecords"
    ).innerText = visibleCount;

}


/* =========================================================
   COUNT UNIQUE DEPARTMENTS
========================================================= */

function countDepartments(){

    var rows =
        document.querySelectorAll(
            "#employeeTable tbody tr"
        );


    var departments = [];


    rows.forEach(function(row){

        if(row.children.length === 11){

            var department =
                row.children[5]
                .innerText
                .trim()
                .toLowerCase();


            if(
                department !== "" &&
                !departments.includes(department)
            ){

                departments.push(department);

            }

        }

    });


    document.getElementById(
        "totalDepartments"
    ).innerText =
        departments.length;

}


/* =========================================================
   PAGE LOAD
========================================================= */

window.onload = function(){

    updateEmployeeCount();

    countDepartments();

};

</script>


</body>

</html>