<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Accenture | Add Employee</title>

<style>

/* =========================
   GLOBAL
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #e3f2fd,
            #f3e5f5,
            #e8eaf6
        );

    color: #263238;
}


/* =========================
   HEADER
========================= */

.header {

    height: 72px;

    background:
        linear-gradient(
            135deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 4px 15px rgba(0,0,0,0.15);
}


/* Logo */

.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 43px;
    height: 43px;

    background: white;

    color: #0d47a1;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    font-weight: bold;

    font-size: 18px;
}

.company {

    font-size: 20px;

    font-weight: bold;
}

.portal {

    font-size: 11px;

    opacity: 0.8;

    margin-top: 3px;
}


/* Back button */

.back-btn {

    color: white;

    text-decoration: none;

    padding: 10px 18px;

    border-radius: 8px;

    background: rgba(255,255,255,0.15);

    font-size: 14px;

    transition: 0.3s;
}

.back-btn:hover {

    background: rgba(255,255,255,0.28);

    transform: translateY(-2px);
}


/* =========================
   PAGE
========================= */

.page {

    display: flex;

    justify-content: center;

    padding: 40px 20px 60px;
}


/* =========================
   FORM CARD
========================= */

.container {

    width: 100%;

    max-width: 750px;

    background: white;

    border-radius: 18px;

    box-shadow:
        0 12px 35px rgba(0,0,0,0.12);

    overflow: hidden;
}


/* =========================
   FORM HEADER
========================= */

.form-header {

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #1976d2
        );

    color: white;

    padding: 25px 30px;
}

.form-header h1 {

    font-size: 25px;

    margin-bottom: 7px;
}

.form-header p {

    font-size: 13px;

    opacity: 0.85;
}


/* =========================
   FORM BODY
========================= */

.form-body {

    padding: 30px;
}


/* Section */

.section-title {

    font-size: 17px;

    font-weight: bold;

    color: #102a43;

    margin-bottom: 20px;

    padding-bottom: 10px;

    border-bottom: 2px solid #e3f2fd;
}


/* =========================
   FORM GRID
========================= */

.form-grid {

    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 20px;
}


.form-group {

    display: flex;

    flex-direction: column;
}


/* Full width */

.full-width {

    grid-column: 1 / -1;
}


/* Labels */

label {

    font-size: 13px;

    font-weight: bold;

    color: #455a64;

    margin-bottom: 7px;
}


/* Inputs */

input,
select {

    width: 100%;

    padding: 12px 13px;

    border: 1px solid #cfd8dc;

    border-radius: 8px;

    background: #fafcff;

    font-size: 14px;

    color: #263238;

    outline: none;

    transition: 0.25s;
}


input:focus,
select:focus {

    border-color: #1976d2;

    background: white;

    box-shadow:
        0 0 0 3px rgba(25,118,210,0.10);
}


input:hover,
select:hover {

    border-color: #90caf9;
}


/* Placeholder */

input::placeholder {

    color: #90a4ae;
}


/* =========================
   BUTTONS
========================= */

.button-area {

    display: flex;

    justify-content: flex-end;

    gap: 12px;

    margin-top: 30px;

    padding-top: 22px;

    border-top: 1px solid #eceff1;
}


/* Reset */

.reset-btn {

    padding: 12px 22px;

    border: 1px solid #b0bec5;

    background: white;

    color: #455a64;

    border-radius: 8px;

    cursor: pointer;

    font-size: 14px;

    transition: 0.3s;
}

.reset-btn:hover {

    background: #eceff1;
}


/* Save */

.save-btn {

    padding: 12px 28px;

    border: none;

    background:
        linear-gradient(
            135deg,
            #1976d2,
            #0d47a1
        );

    color: white;

    border-radius: 8px;

    cursor: pointer;

    font-size: 14px;

    font-weight: bold;

    transition: 0.3s;
}

.save-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 6px 15px rgba(13,71,161,0.25);
}


/* =========================
   INFORMATION BOX
========================= */

.info-box {

    margin-top: 25px;

    padding: 14px 16px;

    background: #e3f2fd;

    border-left: 4px solid #1976d2;

    border-radius: 6px;

    color: #37474f;

    font-size: 12px;

    line-height: 1.6;
}


/* =========================
   FOOTER
========================= */

.footer {

    text-align: center;

    color: #78909c;

    font-size: 12px;

    padding: 15px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 650px) {

    .header {

        padding: 0 15px;
    }

    .company {

        font-size: 16px;
    }

    .portal {

        display: none;
    }

    .form-grid {

        grid-template-columns: 1fr;
    }

    .full-width {

        grid-column: auto;
    }

    .form-body {

        padding: 22px;
    }

    .button-area {

        flex-direction: column;
    }

    .reset-btn,
    .save-btn {

        width: 100%;
    }

}

</style>

</head>


<body>


<!-- =========================
     HEADER
========================= -->

<div class="header">

    <div class="logo-area">

        <div class="logo">
            AP
        </div>

        <div>

            <div class="company">
                Accenture plc
            </div>

            <div class="portal">
                Employee Management Portal
            </div>

        </div>

    </div>


    <a href="dashboard.jsp"
       class="back-btn">

        ← Back to Dashboard

    </a>

</div>



<!-- =========================
     PAGE
========================= -->

<div class="page">


    <div class="container">


        <!-- FORM HEADER -->

        <div class="form-header">

            <h1>
                Add New Employee
            </h1>

            <p>
                Enter the employee details to register
                a new employee in the system.
            </p>

        </div>



        <!-- FORM BODY -->

        <div class="form-body">


            <div class="section-title">

                Employee Information

            </div>


            <!-- IMPORTANT:
                 Same servlet and same field names
            -->

            <form
                action="AddEmployeeServlet"
                method="post"
                onsubmit="return validateEmployeeForm();">


                <div class="form-grid">


                    <!-- Employee Name -->

                    <div class="form-group full-width">

                        <label for="name">
                            Employee Name
                        </label>

                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="Enter employee full name"
                            required>

                    </div>



                    <!-- Gender -->

                    <div class="form-group">

                        <label for="gender">
                            Gender
                        </label>

                        <select
                            id="gender"
                            name="gender"
                            required>

                            <option value="">
                                Select Gender
                            </option>

                            <option value="Male">
                                Male
                            </option>

                            <option value="Female">
                                Female
                            </option>

                        </select>

                    </div>



                    <!-- Email -->

                    <div class="form-group">

                        <label for="email">
                            Email Address
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="example@email.com"
                            required>

                    </div>



                    <!-- Mobile -->

                    <div class="form-group">

                        <label for="mobile">
                            Mobile Number
                        </label>

                        <input
                            type="text"
                            id="mobile"
                            name="mobile"
                            placeholder="Enter mobile number"
                            maxlength="10"
                            required>

                    </div>



                    <!-- Department -->

                    <div class="form-group">

                        <label for="department">
                            Department
                        </label>

                        <input
                            type="text"
                            id="department"
                            name="department"
                            placeholder="e.g. IT, HR, Finance"
                            required>

                    </div>



                    <!-- Designation -->

                    <div class="form-group">

                        <label for="designation">
                            Designation
                        </label>

                        <input
                            type="text"
                            id="designation"
                            name="designation"
                            placeholder="e.g. Software Developer"
                            required>

                    </div>



                    <!-- Salary -->

                    <div class="form-group">

                        <label for="salary">
                            Basic Salary
                        </label>

                        <input
                            type="number"
                            id="salary"
                            name="salary"
                            placeholder="Enter basic salary"
                            min="0"
                            required>

                    </div>



                    <!-- Joining Date -->

                    <div class="form-group">

                        <label for="joiningDate">
                            Joining Date
                        </label>

                        <input
                            type="date"
                            id="joiningDate"
                            name="joiningDate"
                            required>

                    </div>


                </div>



                <!-- INFORMATION -->

                <div class="info-box">

                    <strong>Note:</strong>

                    Please make sure that all employee
                    information is correct before saving.
                    The details will be submitted to the
                    Employee Management System.

                </div>



                <!-- BUTTONS -->

                <div class="button-area">


                    <button
                        type="reset"
                        class="reset-btn">

                        Clear Form

                    </button>


                    <button
                        type="submit"
                        class="save-btn">

                        Save Employee

                    </button>


                </div>


            </form>


        </div>


    </div>

</div>



<!-- =========================
     FOOTER
========================= -->

<div class="footer">

    © 2026 Accenture Employee Management Portal

</div>



<!-- =========================
     INTERNAL JAVASCRIPT
========================= -->

<script>

function validateEmployeeForm() {

    var mobile =
        document.getElementById("mobile").value.trim();

    var salary =
        document.getElementById("salary").value;

    var name =
        document.getElementById("name").value.trim();


    /* Name validation */

    if (name.length < 2) {

        alert("Please enter a valid employee name.");

        return false;
    }


    /* Mobile validation */

    if (!/^[0-9]{10}$/.test(mobile)) {

        alert(
            "Please enter a valid 10-digit mobile number."
        );

        return false;
    }


    /* Salary validation */

    if (salary <= 0) {

        alert(
            "Basic salary must be greater than zero."
        );

        return false;
    }


    return true;

}

</script>


</body>

</html>