<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>500 - Internal Server Error | Employee Management</title>

<style>

/* =========================================================
   GLOBAL
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    min-height:100vh;

    font-family:"Segoe UI",Arial,Helvetica,sans-serif;

    background:
        linear-gradient(
            135deg,
            #e3f2fd,
            #f5f9ff,
            #dbeafe
        );

    display:flex;

    align-items:center;

    justify-content:center;

    color:#263238;
}


/* =========================================================
   ERROR CONTAINER
========================================================= */

.error-wrapper{
    width:92%;

    max-width:600px;

    text-align:center;
}


/* =========================================================
   ERROR CARD
========================================================= */

.error-card{
    background:rgba(255,255,255,0.97);

    padding:45px 40px;

    border-radius:20px;

    box-shadow:
        0 15px 40px rgba(13,71,161,0.16);

    border:1px solid rgba(21,101,192,0.08);

    animation:fadeIn 0.5s ease;
}


/* =========================================================
   LOGO
========================================================= */

.logo{
    width:55px;

    height:55px;

    margin:0 auto 18px;

    border-radius:13px;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #0d47a1
        );

    color:white;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:20px;

    font-weight:800;

    box-shadow:
        0 7px 15px rgba(21,101,192,0.25);
}


/* =========================================================
   ERROR ICON
========================================================= */

.error-icon{
    width:95px;

    height:95px;

    margin:0 auto 20px;

    border-radius:50%;

    background:#ffebee;

    color:#c62828;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:45px;

    font-weight:800;

    border:6px solid #ffcdd2;
}


/* =========================================================
   ERROR CODE
========================================================= */

.error-code{
    color:#0d47a1;

    font-size:58px;

    line-height:1;

    font-weight:800;

    margin-bottom:8px;
}


/* =========================================================
   HEADING
========================================================= */

h2{
    color:#263238;

    font-size:24px;

    margin-bottom:12px;
}


/* =========================================================
   DESCRIPTION
========================================================= */

.message{
    color:#607d8b;

    font-size:14px;

    line-height:1.7;

    margin-bottom:28px;
}


/* =========================================================
   BUTTON
========================================================= */

.home-btn{
    display:inline-block;

    text-decoration:none;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #0d47a1
        );

    color:white;

    padding:13px 25px;

    border-radius:9px;

    font-size:14px;

    font-weight:600;

    box-shadow:
        0 6px 15px rgba(21,101,192,0.25);

    transition:0.25s;
}

.home-btn:hover{
    color:white;

    transform:translateY(-2px);

    box-shadow:
        0 9px 20px rgba(13,71,161,0.32);
}


/* =========================================================
   FOOTER
========================================================= */

.footer{
    margin-top:20px;

    color:#78909c;

    font-size:11px;
}


/* =========================================================
   ANIMATION
========================================================= */

@keyframes fadeIn{

    from{
        opacity:0;

        transform:translateY(15px);
    }

    to{
        opacity:1;

        transform:translateY(0);
    }

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:500px){

    .error-card{
        padding:35px 22px;
    }

    .error-code{
        font-size:48px;
    }

    h2{
        font-size:20px;
    }

    .error-icon{
        width:80px;

        height:80px;

        font-size:36px;
    }

}

</style>

</head>


<body>


<div class="error-wrapper">


    <div class="error-card">


        <!-- COMPANY LOGO -->

        <div class="logo">
            AP
        </div>


        <!-- ERROR ICON -->

        <div class="error-icon">
            !
        </div>


        <!-- ERROR CODE -->

        <div class="error-code">
            500
        </div>


        <!-- ERROR TITLE -->

        <h2>
            Internal Server Error
        </h2>


        <!-- MESSAGE -->

        <p class="message">
            Something went wrong while processing your request.
            Please try again or return to the Employee Management Dashboard.
        </p>


        <!-- HOME BUTTON -->

        <a
            href="dashboard.jsp"
            class="home-btn">

            ← Go to Dashboard

        </a>


    </div>


    <!-- FOOTER -->

    <div class="footer">

        © 2026 Accenture plc
        • Employee Payroll & Management System

    </div>


</div>


</body>

</html>