<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<title>Employee Payroll System - Login</title>

<style>

body {
    font-family: Arial;
    background: linear-gradient(135deg,#141e30,#243b55);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.login-box {
    width: 350px;
    padding: 35px;
    background: white;
    border-radius: 15px;
    text-align: center;
}

input {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 12px;
    background: #0072ff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.error {
    color: red;
    margin-top: 15px;
}

</style>

</head>

<body>

<div class="login-box">

<h2>👨‍💼 Employee Payroll System</h2>

<form action="Loginservlet" method="post">

<input
    type="text"
    name="username"
    placeholder="Username"
    required>

<input
    type="password"
    name="password"
    placeholder="Password"
    required>

<button type="submit">
    Login
</button>

</form>

<%
if(request.getParameter("error") != null) {
%>

<div class="error">
    Invalid Username or Password
</div>

<%
}
%>

</div>

</body>

</html>