
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="dao.EmployeeDAO"%>
<%@ page import="model.Employee"%>

<%

int id = Integer.parseInt(request.getParameter("id"));

EmployeeDAO dao = new EmployeeDAO();

Employee e = dao.getEmployeeById(id);

%>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Accenture | Edit Employee</title>


<style>

/* =========================
   GLOBAL
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family: Arial, Helvetica, sans-serif;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #e3f2fd,
            #f3e5f5,
            #e8eaf6
        );

    color: #263238;
}


/* =========================
   HEADER
========================= */

.header {

    height: 72px;

    width: 100%;

    background:
        linear-gradient(
            135deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 4px 15px rgba(0,0,0,0.15);
}


/* Logo */

.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 43px;

    height: 43px;

    border-radius: 10px;

    background: white;

    color: #0d47a1;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

    font-weight: bold;
}


.company-name {

    font-size: 20px;

    font-weight: bold;
}


.portal-name {

    font-size: 11px;

    opacity: 0.8;

    margin-top: 3px;
}


/* Back button */

.back-btn {

    color: white;

    text-decoration: none;

    padding: 10px 18px;

    background:
        rgba(255,255,255,0.15);

    border-radius: 8px;

    font-size: 14px;

    transition: 0.3s;
}


.back-btn:hover {

    background:
        rgba(255,255,255,0.28);

    transform: translateY(-2px);
}


/* =========================
   MAIN PAGE
========================= */

.page {

    display: flex;

    justify-content: center;

    padding: 40px 20px 60px;
}


/* =========================
   FORM CONTAINER
========================= */

.container {

    width: 100%;

    max-width: 780px;

    background: white;

    border-radius: 18px;

    overflow: hidden;

    box-shadow:
        0 12px 35px rgba(0,0,0,0.12);
}


/* =========================
   FORM HEADER
========================= */

.form-header {

    background:
        linear-gradient(
            135deg,
            #1976d2,
            #0d47a1
        );

    color: white;

    padding: 27px 30px;
}


.header-icon {

    width: 48px;

    height: 48px;

    border-radius: 12px;

    background:
        rgba(255,255,255,0.18);

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 23px;

    margin-bottom: 13px;
}


.form-header h1 {

    font-size: 25px;

    margin-bottom: 7px;
}


.form-header p {

    font-size: 13px;

    opacity: 0.85;

    line-height: 1.5;
}


/* =========================
   EMPLOYEE ID
========================= */

.employee-id {

    margin: 25px 30px 0;

    padding: 14px 16px;

    background: #e3f2fd;

    border-left: 4px solid #1976d2;

    border-radius: 7px;

    font-size: 13px;

    color: #455a64;
}


.employee-id strong {

    color: #0d47a1;
}


/* =========================
   FORM BODY
========================= */

.form-body {

    padding: 25px 30px 30px;
}


.section-title {

    font-size: 17px;

    font-weight: bold;

    color: #102a43;

    padding-bottom: 11px;

    margin-bottom: 22px;

    border-bottom:
        2px solid #e3f2fd;
}


/* =========================
   FORM GRID
========================= */

.form-grid {

    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 20px;
}


.form-group {

    display: flex;

    flex-direction: column;
}


.full-width {

    grid-column: 1 / -1;
}


label {

    font-size: 13px;

    font-weight: bold;

    color: #455a64;

    margin-bottom: 7px;
}


/* =========================
   INPUTS
========================= */

input,
select {

    width: 100%;

    padding: 12px 13px;

    border:
        1px solid #cfd8dc;

    border-radius: 8px;

    background: #fafcff;

    color: #263238;

    font-size: 14px;

    outline: none;

    transition: 0.25s;
}


input:focus,
select:focus {

    background: white;

    border-color: #1976d2;

    box-shadow:
        0 0 0 3px
        rgba(25,118,210,0.10);
}


input:hover,
select:hover {

    border-color: #90caf9;
}


/* Employee ID readonly */

.id-input {

    background: #eceff1;

    color: #546e7a;

    cursor: not-allowed;
}


/* =========================
   INFORMATION BOX
========================= */

.info-box {

    margin-top: 25px;

    padding: 14px 16px;

    background: #fff8e1;

    border-left:
        4px solid #ffb300;

    border-radius: 6px;

    color: #5d4037;

    font-size: 12px;

    line-height: 1.6;
}


/* =========================
   BUTTON AREA
========================= */

.button-area {

    display: flex;

    justify-content: flex-end;

    gap: 12px;

    margin-top: 28px;

    padding-top: 22px;

    border-top:
        1px solid #eceff1;
}


/* Cancel */

.cancel-btn {

    padding: 12px 22px;

    border:
        1px solid #b0bec5;

    background: white;

    color: #455a64;

    border-radius: 8px;

    text-decoration: none;

    font-size: 14px;

    transition: 0.3s;
}


.cancel-btn:hover {

    background: #eceff1;
}


/* Update */

.update-btn {

    padding: 12px 28px;

    border: none;

    border-radius: 8px;

    background:
        linear-gradient(
            135deg,
            #1976d2,
            #0d47a1
        );

    color: white;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;

    transition: 0.3s;
}


.update-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 6px 15px
        rgba(13,71,161,0.25);
}


/* =========================
   FOOTER
========================= */

.footer {

    text-align: center;

    color: #78909c;

    font-size: 12px;

    padding: 18px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 650px) {

    .header {

        padding: 0 15px;
    }

    .company-name {

        font-size: 16px;
    }

    .portal-name {

        display: none;
    }

    .form-grid {

        grid-template-columns: 1fr;
    }

    .full-width {

        grid-column: auto;
    }

    .form-body {

        padding: 22px;
    }

    .employee-id {

        margin-left: 22px;

        margin-right: 22px;
    }

    .button-area {

        flex-direction: column;
    }

    .cancel-btn,
    .update-btn {

        width: 100%;

        text-align: center;
    }

}

</style>

</head>


<body>


<!-- =========================
     HEADER
========================= -->

<div class="header">

    <div class="logo-area">

        <div class="logo">
            AP
        </div>

        <div>

            <div class="company-name">
                Accenture plc
            </div>

            <div class="portal-name">
                Employee Management Portal
            </div>

        </div>

    </div>


    <a href="dashboard.jsp"
       class="back-btn">

        ← Back to Dashboard

    </a>

</div>



<!-- =========================
     MAIN PAGE
========================= -->

<div class="page">


    <div class="container">


        <!-- FORM HEADER -->

        <div class="form-header">

            <div class="header-icon">
                ✏️
            </div>

            <h1>
                Edit Employee
            </h1>

            <p>
                Update the employee information
                maintained in the payroll system.
            </p>

        </div>



        <!-- EMPLOYEE ID -->

        <div class="employee-id">

            Employee ID:

            <strong>
                <%=e.getEmpId()%>
            </strong>

        </div>



        <!-- FORM BODY -->

        <div class="form-body">


            <div class="section-title">

                Employee Information

            </div>



            <!-- IMPORTANT:
                 Existing servlet and parameter
                 names are unchanged.
            -->

            <form
                action="UpdateEmployeeServlet"
                method="post"
                onsubmit="return validateEmployee();">


                <!-- Hidden Employee ID -->

                <input
                    type="hidden"
                    name="id"
                    value="<%=e.getEmpId()%>">



                <div class="form-grid">


                    <!-- Employee Name -->

                    <div class="form-group full-width">

                        <label for="name">
                            Employee Name
                        </label>

                        <input
                            type="text"
                            id="name"
                            name="name"
                            value="<%=e.getName()%>"
                            placeholder="Enter employee name"
                            required>

                    </div>



                    <!-- Gender -->

                    <div class="form-group">

                        <label for="gender">
                            Gender
                        </label>

                        <select
                            id="gender"
                            name="gender"
                            required>

                            <option
                                value="Male"
                                <%=e.getGender().equals("Male")
                                ? "selected" : ""%>>

                                Male

                            </option>

                            <option
                                value="Female"
                                <%=e.getGender().equals("Female")
                                ? "selected" : ""%>>

                                Female

                            </option>

                        </select>

                    </div>



                    <!-- Email -->

                    <div class="form-group">

                        <label for="email">
                            Email Address
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<%=e.getEmail()%>"
                            placeholder="example@email.com"
                            required>

                    </div>



                    <!-- Mobile -->

                    <div class="form-group">

                        <label for="mobile">
                            Mobile Number
                        </label>

                        <input
                            type="text"
                            id="mobile"
                            name="mobile"
                            value="<%=e.getMobile()%>"
                            placeholder="Enter mobile number"
                            maxlength="10"
                            required>

                    </div>



                    <!-- Department -->

                    <div class="form-group">

                        <label for="department">
                            Department
                        </label>

                        <input
                            type="text"
                            id="department"
                            name="department"
                            value="<%=e.getDepartment()%>"
                            placeholder="Enter department"
                            required>

                    </div>



                    <!-- Designation -->

                    <div class="form-group">

                        <label for="designation">
                            Designation
                        </label>

                        <input
                            type="text"
                            id="designation"
                            name="designation"
                            value="<%=e.getDesignation()%>"
                            placeholder="Enter designation"
                            required>

                    </div>



                    <!-- Salary -->

                    <div class="form-group">

                        <label for="salary">
                            Basic Salary
                        </label>

                        <input
                            type="number"
                            id="salary"
                            name="salary"
                            value="<%=e.getBasicSalary()%>"
                            placeholder="Enter basic salary"
                            min="0"
                            required>

                    </div>



                    <!-- Joining Date -->

                    <div class="form-group">

                        <label for="joiningDate">
                            Joining Date
                        </label>

                        <input
                            type="date"
                            id="joiningDate"
                            name="joiningDate"
                            value="<%=e.getJoiningDate()%>"
                            required>

                    </div>


                </div>



                <!-- INFORMATION -->

                <div class="info-box">

                    <strong>Important:</strong>

                    Please verify the updated employee
                    information before clicking
                    "Update Employee".

                </div>



                <!-- BUTTONS -->

                <div class="button-area">


                    <a
                        href="ViewEmployeeServlet"
                        class="cancel-btn">

                        Cancel

                    </a>


                    <button
                        type="submit"
                        class="update-btn">

                        ✓ Update Employee

                    </button>


                </div>


            </form>


        </div>


    </div>

</div>



<!-- =========================
     FOOTER
========================= -->

<div class="footer">

    © 2026 Accenture Employee Management Portal

</div>



<!-- =========================
     INTERNAL JAVASCRIPT
========================= -->

<script>

function validateEmployee() {

    var name =
        document.getElementById("name")
        .value
        .trim();

    var mobile =
        document.getElementById("mobile")
        .value
        .trim();

    var salary =
        document.getElementById("salary")
        .value;


    /* Name validation */

    if(name.length < 2) {

        alert(
            "Please enter a valid employee name."
        );

        return false;
    }


    /* Mobile validation */

    if(!/^[0-9]{10}$/.test(mobile)) {

        alert(
            "Please enter a valid 10-digit mobile number."
        );

        return false;
    }


    /* Salary validation */

    if(salary <= 0) {

        alert(
            "Basic salary must be greater than zero."
        );

        return false;
    }


    /* Confirmation */

    return confirm(
        "Are you sure you want to update this employee?"
    );

}

</script>


</body>

</html>

