<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="model.Employee" %>

<%

Employee employee =
    (Employee) request.getAttribute("employee");

if(employee == null) {

    response.sendRedirect("login.jsp");

    return;
}

%>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>My Profile</title>

<style>

body {

    margin: 0;

    font-family: Arial;

    background: linear-gradient(
        135deg,
        #141e30,
        #243b55
    );

    min-height: 100vh;

    padding: 40px;
}

.container {

    max-width: 850px;

    margin: auto;

    background: white;

    border-radius: 20px;

    padding: 35px;

    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

h1 {

    color: #243b55;

    text-align: center;

}

.profile {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;

    margin-top: 30px;
}

.info {

    padding: 18px;

    background: #f4f7fb;

    border-radius: 12px;
}

.info b {

    color: #243b55;
}

.back {

    display: inline-block;

    margin-top: 25px;

    padding: 12px 20px;

    background: #0072ff;

    color: white;

    text-decoration: none;

    border-radius: 8px;
}

</style>

</head>

<body>

<div class="container">

<h1>👤 My Employee Profile</h1>

<div class="profile">

<div class="info">
<b>Employee ID</b><br>
<%= employee.getEmpId() %>
</div>

<div class="info">
<b>Name</b><br>
<%= employee.getName() %>
</div>

<div class="info">
<b>Gender</b><br>
<%= employee.getGender() %>
</div>

<div class="info">
<b>Email</b><br>
<%= employee.getEmail() %>
</div>

<div class="info">
<b>Mobile</b><br>
<%= employee.getMobile() %>
</div>

<div class="info">
<b>Department</b><br>
<%= employee.getDepartment() %>
</div>

<div class="info">
<b>Designation</b><br>
<%= employee.getDesignation() %>
</div>

<div class="info">
<b>Basic Salary</b><br>
₹ <%= employee.getBasicSalary() %>
</div>

<div class="info">
<b>Joining Date</b><br>
<%= employee.getJoiningDate() %>
</div>

</div>

<a href="dashboard.jsp" class="back">
⬅ Back to Dashboard
</a>

</div>

</body>

</html>