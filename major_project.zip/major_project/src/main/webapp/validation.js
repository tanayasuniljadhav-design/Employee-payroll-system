function validateEmployee() {

    /* =========================
       GET FORM VALUES
    ========================= */

    var name =
        document.forms["empForm"]["name"].value.trim();

    var email =
        document.forms["empForm"]["email"].value.trim();

    var mobile =
        document.forms["empForm"]["mobile"].value.trim();


    /* =========================
       NAME VALIDATION
    ========================= */

    if (name === "") {

        alert("⚠️ Employee Name is required.");

        document.forms["empForm"]["name"].focus();

        return false;
    }


    if (name.length < 2) {

        alert("⚠️ Employee Name must contain at least 2 characters.");

        document.forms["empForm"]["name"].focus();

        return false;
    }


    /* =========================
       NAME CHARACTER VALIDATION
    ========================= */

    var namePattern =
        /^[A-Za-z ]+$/;

    if (!namePattern.test(name)) {

        alert(
            "⚠️ Employee Name should contain only letters and spaces."
        );

        document.forms["empForm"]["name"].focus();

        return false;
    }


    /* =========================
       EMAIL VALIDATION
    ========================= */

    if (email === "") {

        alert("⚠️ Email address is required.");

        document.forms["empForm"]["email"].focus();

        return false;
    }


    var emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {

        alert("⚠️ Please enter a valid email address.");

        document.forms["empForm"]["email"].focus();

        return false;
    }


    /* =========================
       MOBILE VALIDATION
    ========================= */

    if (mobile === "") {

        alert("⚠️ Mobile number is required.");

        document.forms["empForm"]["mobile"].focus();

        return false;
    }


    var mobilePattern =
        /^[0-9]{10}$/;

    if (!mobilePattern.test(mobile)) {

        alert(
            "⚠️ Mobile Number must contain exactly 10 digits."
        );

        document.forms["empForm"]["mobile"].focus();

        return false;
    }


    /* =========================
       SUCCESS
    ========================= */

    return true;
}