<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@page import="java.util.*"%>
<%@page import="model.Salary"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Salary Report | Accenture Employee Management</title>

<style>

/* =========================
   GLOBAL
========================= */

*{
    box-sizing:border-box;
    margin:0;
    padding:0;
}

body{
    font-family:"Segoe UI",Arial,sans-serif;
    background:linear-gradient(135deg,#e3f2fd,#f4f8ff,#dbeafe);
    min-height:100vh;
    color:#172b4d;
}

/* =========================
   HEADER
========================= */

.header{
    height:75px;
    background:linear-gradient(135deg,#0d47a1,#1565c0,#1976d2);
    color:white;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 35px;
    box-shadow:0 4px 15px rgba(0,0,0,0.18);
}

.logo-section{
    display:flex;
    align-items:center;
    gap:14px;
}

.logo{
    width:45px;
    height:45px;
    border-radius:10px;
    background:white;
    color:#1565c0;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:21px;
    font-weight:bold;
}

.company-name{
    font-size:20px;
    font-weight:700;
}

.portal-name{
    font-size:12px;
    opacity:0.85;
    margin-top:2px;
}

.header-right{
    font-size:14px;
    opacity:0.95;
}

/* =========================
   MAIN CONTAINER
========================= */

.container{
    width:94%;
    max-width:1450px;
    margin:30px auto;
}

/* =========================
   PAGE TOP
========================= */

.page-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.page-title h1{
    font-size:30px;
    color:#0d47a1;
    margin-bottom:5px;
}

.page-title p{
    color:#607d8b;
    font-size:14px;
}

.dashboard-btn{
    text-decoration:none;
    background:linear-gradient(135deg,#1565c0,#0d47a1);
    color:white;
    padding:12px 20px;
    border-radius:9px;
    font-size:14px;
    font-weight:600;
    box-shadow:0 5px 12px rgba(21,101,192,0.25);
    transition:0.3s;
}

.dashboard-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 18px rgba(21,101,192,0.35);
}

/* =========================
   SUMMARY CARDS
========================= */

.summary{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
    margin-bottom:25px;
}

.summary-card{
    background:rgba(255,255,255,0.92);
    border-radius:15px;
    padding:22px;
    display:flex;
    align-items:center;
    gap:18px;
    box-shadow:0 7px 22px rgba(21,101,192,0.12);
    border-left:5px solid #1565c0;
}

.summary-icon{
    width:52px;
    height:52px;
    border-radius:12px;
    background:#e3f2fd;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:25px;
}

.summary-card h4{
    color:#607d8b;
    font-size:13px;
    margin-bottom:5px;
}

.summary-card h2{
    color:#0d47a1;
    font-size:24px;
}

/* =========================
   REPORT CARD
========================= */

.report-card{
    background:rgba(255,255,255,0.95);
    border-radius:16px;
    padding:25px;
    box-shadow:0 10px 30px rgba(13,71,161,0.13);
}

/* =========================
   TOOLBAR
========================= */

.toolbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:15px;
    margin-bottom:20px;
    flex-wrap:wrap;
}

.search-box{
    position:relative;
    flex:1;
    min-width:250px;
}

.search-box input{
    width:100%;
    padding:13px 15px 13px 42px;
    border:1px solid #cfd8e3;
    border-radius:9px;
    outline:none;
    font-size:14px;
    background:#f8fbff;
}

.search-box input:focus{
    border-color:#1976d2;
    box-shadow:0 0 0 3px rgba(25,118,210,0.12);
}

.search-icon{
    position:absolute;
    left:14px;
    top:11px;
    font-size:18px;
}

.clear-btn{
    padding:12px 18px;
    border:none;
    border-radius:8px;
    background:#eceff1;
    color:#37474f;
    cursor:pointer;
    font-weight:600;
}

.clear-btn:hover{
    background:#cfd8dc;
}

/* =========================
   TABLE
========================= */

.table-wrapper{
    width:100%;
    overflow-x:auto;
    border-radius:12px;
    border:1px solid #e0e7ef;
}

table{
    width:100%;
    min-width:950px;
    border-collapse:collapse;
    background:white;
}

th{
    background:linear-gradient(135deg,#0d47a1,#1565c0);
    color:white;
    padding:15px 12px;
    font-size:13px;
    text-align:center;
    white-space:nowrap;
}

td{
    padding:13px 12px;
    text-align:center;
    border-bottom:1px solid #e8edf3;
    font-size:13px;
    color:#37474f;
}

tbody tr{
    transition:0.2s;
}

tbody tr:hover{
    background:#f1f7ff;
}

/* Salary columns */

.salary{
    font-weight:600;
    color:#1565c0;
}

.net-salary{
    font-weight:700;
    color:#0b7a42;
}

/* =========================
   EMPTY MESSAGE
========================= */

.no-data{
    text-align:center;
    padding:35px;
    color:#78909c;
    font-size:15px;
}

.no-data-icon{
    font-size:38px;
    margin-bottom:8px;
}

/* =========================
   FOOTER
========================= */

.footer{
    text-align:center;
    margin-top:25px;
    padding:15px;
    color:#607d8b;
    font-size:12px;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .summary{
        grid-template-columns:1fr;
    }

    .page-top{
        flex-direction:column;
        align-items:flex-start;
        gap:15px;
    }

    .header{
        padding:0 18px;
    }

    .header-right{
        display:none;
    }

    .container{
        width:96%;
    }
}

@media(max-width:600px){

    .company-name{
        font-size:16px;
    }

    .portal-name{
        font-size:10px;
    }

    .page-title h1{
        font-size:24px;
    }

    .report-card{
        padding:15px;
    }

    .toolbar{
        flex-direction:column;
        align-items:stretch;
    }

    .search-box{
        min-width:100%;
    }

    .clear-btn{
        width:100%;
    }

}

</style>

</head>

<body>

<!-- =========================
     HEADER
========================= -->

<div class="header">

    <div class="logo-section">

        <div class="logo">
            AP
        </div>

        <div>
            <div class="company-name">
                Accenture plc
            </div>

            <div class="portal-name">
                Employee Management Portal
            </div>
        </div>

    </div>

    <div class="header-right">
        💼 Payroll Management System
    </div>

</div>


<!-- =========================
     MAIN
========================= -->

<div class="container">

    <!-- PAGE TITLE -->

    <div class="page-top">

        <div class="page-title">

            <h1>Salary Report</h1>

            <p>
                View and monitor employee salary details
            </p>

        </div>

        <a href="dashboard.jsp" class="dashboard-btn">
            ← Back to Dashboard
        </a>

    </div>


    <!-- =========================
         SUMMARY CARDS
    ========================= -->

    <div class="summary">

        <div class="summary-card">

            <div class="summary-icon">
                👥
            </div>

            <div>
                <h4>Total Salary Records</h4>
                <h2 id="totalRecords">0</h2>
            </div>

        </div>


        <div class="summary-card">

            <div class="summary-icon">
                💰
            </div>

            <div>
                <h4>Total Basic Salary</h4>
                <h2 id="totalBasic">₹0</h2>
            </div>

        </div>


        <div class="summary-card">

            <div class="summary-icon">
                🧾
            </div>

            <div>
                <h4>Total Net Salary</h4>
                <h2 id="totalNet">₹0</h2>
            </div>

        </div>

    </div>


    <!-- =========================
         REPORT TABLE
    ========================= -->

    <div class="report-card">

        <div class="toolbar">

            <div class="search-box">

                <span class="search-icon">🔍</span>

                <input
                    type="text"
                    id="salarySearch"
                    placeholder="Search by Employee ID or Month..."
                    onkeyup="searchSalary()">

            </div>

            <button
                type="button"
                class="clear-btn"
                onclick="clearSearch()">
                Clear Search
            </button>

        </div>


        <div class="table-wrapper">

            <table id="salaryTable">

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Employee ID</th>

                        <th>Month</th>

                        <th>Basic</th>

                        <th>HRA</th>

                        <th>DA</th>

                        <th>PF</th>

                        <th>Tax</th>

                        <th>Net Salary</th>

                    </tr>

                </thead>

                <tbody>

                <%

                ArrayList<Salary> list =
                (ArrayList<Salary>)request.getAttribute("salaryList");

                if(list!=null && !list.isEmpty()){

                    for(Salary s:list){

                %>

                    <tr>

                        <td>
                            <%=s.getSalaryId()%>
                        </td>

                        <td>
                            <strong>
                                EMP-<%=s.getEmpId()%>
                            </strong>
                        </td>

                        <td>
                            <%=s.getMonth()%>
                        </td>

                        <td class="salary">
                            ₹<%=s.getBasic()%>
                        </td>

                        <td>
                            ₹<%=s.getHra()%>
                        </td>

                        <td>
                            ₹<%=s.getDa()%>
                        </td>

                        <td>
                            ₹<%=s.getPf()%>
                        </td>

                        <td>
                            ₹<%=s.getTax()%>
                        </td>

                        <td class="net-salary">
                            ₹<%=s.getNetSalary()%>
                        </td>

                    </tr>

                <%

                    }

                }else{

                %>

                    <tr>

                        <td colspan="9">

                            <div class="no-data">

                                <div class="no-data-icon">
                                    📄
                                </div>

                                No salary records found.

                            </div>

                        </td>

                    </tr>

                <%

                }

                %>

                </tbody>

            </table>

        </div>

    </div>


    <div class="footer">

        © 2026 Accenture plc • Employee Payroll & Management System

    </div>

</div>


<!-- =========================
     JAVASCRIPT
========================= -->

<script>

/* =========================
   SEARCH SALARY
========================= */

function searchSalary(){

    let input =
        document.getElementById("salarySearch")
        .value
        .toLowerCase();

    let rows =
        document.querySelectorAll("#salaryTable tbody tr");

    rows.forEach(function(row){

        let text =
            row.innerText.toLowerCase();

        if(text.includes(input)){

            row.style.display = "";

        }else{

            row.style.display = "none";

        }

    });

}


/* =========================
   CLEAR SEARCH
========================= */

function clearSearch(){

    document.getElementById("salarySearch").value = "";

    let rows =
        document.querySelectorAll("#salaryTable tbody tr");

    rows.forEach(function(row){

        row.style.display = "";

    });

}


/* =========================
   CALCULATE SUMMARY
========================= */

function calculateSummary(){

    let rows =
        document.querySelectorAll("#salaryTable tbody tr");

    let totalRecords = 0;

    let totalBasic = 0;

    let totalNet = 0;


    rows.forEach(function(row){

        if(row.style.display === "none"){
            return;
        }

        let cells = row.children;

        if(cells.length === 9){

            totalRecords++;

            let basic =
                parseFloat(
                    cells[3].innerText
                    .replace("₹","")
                    .replace(/,/g,"")
                ) || 0;

            let net =
                parseFloat(
                    cells[8].innerText
                    .replace("₹","")
                    .replace(/,/g,"")
                ) || 0;

            totalBasic += basic;

            totalNet += net;

        }

    });


    document.getElementById("totalRecords").innerText =
        totalRecords;

    document.getElementById("totalBasic").innerText =
        "₹" + totalBasic.toLocaleString("en-IN");

    document.getElementById("totalNet").innerText =
        "₹" + totalNet.toLocaleString("en-IN");

}


/* =========================
   PAGE LOAD
========================= */

window.onload = function(){

    calculateSummary();

};


/* =========================
   UPDATE SUMMARY AFTER SEARCH
========================= */

document
.getElementById("salarySearch")
.addEventListener("keyup",function(){

    calculateSummary();

});

</script>

</body>
</html>