<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%
    String username = (String) session.getAttribute("username");
    String role = (String) session.getAttribute("role");

    // Check login
    if (username == null || role == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Employee Payroll Dashboard</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f7fb;
            color: #172337;
        }

        /* ================= SIDEBAR ================= */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;

            width: 240px;
            height: 100vh;

            background: linear-gradient(
                180deg,
                #141e30,
                #243b55
            );

            color: white;

            padding: 25px 15px;

            overflow-y: auto;
        }

        .logo {
            text-align: center;

            font-size: 22px;
            font-weight: bold;

            margin-bottom: 35px;

            padding-bottom: 20px;

            border-bottom: 1px solid rgba(255,255,255,0.2);
        }

        .sidebar a {
            display: block;

            text-decoration: none;

            color: white;

            padding: 13px;

            margin: 7px 0;

            border-radius: 8px;

            transition: 0.3s;
        }

        .sidebar a:hover {
            background: #00a8ff;

            transform: translateX(5px);
        }

        .sidebar .logout {
            background: #e74c3c;

            margin-top: 25px;
        }

        .sidebar .logout:hover {
            background: #c0392b;

            transform: none;
        }

        /* ================= MAIN ================= */

        .main {
            margin-left: 240px;

            padding: 30px;

            min-height: 100vh;
        }

        /* ================= TOPBAR ================= */

        .topbar {
            background: white;

            padding: 20px;

            border-radius: 15px;

            box-shadow:
                0 4px 15px rgba(0,0,0,0.08);

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 25px;
        }

        .welcome {
            font-size: 24px;

            font-weight: bold;
        }

        .role {
            padding: 8px 15px;

            border-radius: 20px;

            background: #00a8ff;

            color: white;

            font-weight: bold;

            text-transform: uppercase;
        }

        /* ================= CARDS ================= */

        .cards {
            display: grid;

            grid-template-columns:
                repeat(auto-fit, minmax(200px, 1fr));

            gap: 20px;
        }

        .card {
            padding: 25px;

            border-radius: 15px;

            color: white;

            box-shadow:
                0 5px 15px rgba(0,0,0,0.15);

            transition: 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);

            box-shadow:
                0 10px 25px rgba(0,0,0,0.20);
        }

        .card h2 {
            margin: 0;

            font-size: 30px;
        }

        .card p {
            margin-bottom: 0;

            font-size: 16px;

            font-weight: bold;
        }

        .card1 {
            background:
                linear-gradient(
                    135deg,
                    #667eea,
                    #764ba2
                );
        }

        .card2 {
            background:
                linear-gradient(
                    135deg,
                    #11998e,
                    #38ef7d
                );
        }

        .card3 {
            background:
                linear-gradient(
                    135deg,
                    #ff9966,
                    #ff5e62
                );
        }

        .card4 {
            background:
                linear-gradient(
                    135deg,
                    #396afc,
                    #2948ff
                );
        }

        /* ================= INFORMATION ================= */

        .employee-section {
            margin-top: 30px;

            background: white;

            padding: 25px;

            border-radius: 15px;

            box-shadow:
                0 4px 15px rgba(0,0,0,0.08);
        }

        .employee-section h2 {
            margin-top: 0;

            color: #243b55;
        }

        .employee-section p {
            line-height: 1.7;

            color: #555;

            font-size: 16px;
        }

        /* ================= RESPONSIVE ================= */

        @media (max-width: 768px) {

            .sidebar {
                width: 200px;
            }

            .main {
                margin-left: 200px;

                padding: 20px;
            }

            .welcome {
                font-size: 19px;
            }

        }

        @media (max-width: 600px) {

            .sidebar {
                position: relative;

                width: 100%;

                height: auto;
            }

            .main {
                margin-left: 0;

                padding: 15px;
            }

            .topbar {
                flex-direction: column;

                gap: 15px;

                text-align: center;
            }

            .cards {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>

    <!-- ================= SIDEBAR ================= -->

    <div class="sidebar">

        <div class="logo">
            👨‍💼 Payroll System
        </div>


        <!-- Dashboard -->

        <a href="dashboard.jsp">
            🏠 Dashboard
        </a>


        <!-- ================= ADMIN MENU ================= -->

        <% if ("admin".equalsIgnoreCase(role)) { %>

            <a href="addEmployee.jsp">
                ➕ Add Employee
            </a>

            <a href="ViewEmployeeServlet">
                👥 Employees
            </a>

            <a href="salary.jsp">
                💰 Salary
            </a>

            <a href="SalaryReportServlet">
                📊 Salary Report
            </a>

            <a href="attendance.jsp">
                📅 Attendance
            </a>

            <a href="AttendanceReportServlet">
                📋 Attendance Report
            </a>

            <a href="leave.jsp">
                📝 Leave Management
            </a>

            <a href="LeaveReportServlet">
                📄 Leave Report
            </a>

            <a href="ReportServlet">
                📈 Reports
            </a>


        <!-- ================= EMPLOYEE MENU ================= -->

        <% } else if ("employee".equalsIgnoreCase(role)) { %>

            <a href="EmployeeProfileServlet">
                👤 My Profile
            </a>

            <a href="EmployeeAttendanceServlet">
                📅 My Attendance
            </a>

            <a href="EmployeeSalaryServlet">
                💰 My Salary
            </a>

            <a href="leave.jsp">
                📝 Apply Leave
            </a>

            <a href="EmployeeLeaveServlet">
                📄 My Leave
            </a>

        <% } %>


        <!-- ================= LOGOUT ================= -->

        <a href="LogoutServlet" class="logout">
            🚪 Logout
        </a>

    </div>


    <!-- ================= MAIN CONTENT ================= -->

    <div class="main">


        <!-- TOP BAR -->

        <div class="topbar">

            <div class="welcome">

                Welcome, <%= username %> 👋

            </div>

            <div class="role">

                <%= role %>

            </div>

        </div>


        <!-- ================= DASHBOARD CARDS ================= -->

        <div class="cards">


            <!-- ADMIN CARDS -->

            <% if ("admin".equalsIgnoreCase(role)) { %>

                <div class="card card1">

                    <h2>👥</h2>

                    <p>
                        Manage Employees
                    </p>

                </div>


                <div class="card card2">

                    <h2>💰</h2>

                    <p>
                        Manage Salary
                    </p>

                </div>


                <div class="card card3">

                    <h2>📅</h2>

                    <p>
                        Attendance
                    </p>

                </div>


                <div class="card card4">

                    <h2>📊</h2>

                    <p>
                        Reports
                    </p>

                </div>


            <!-- EMPLOYEE CARDS -->

            <% } else if ("employee".equalsIgnoreCase(role)) { %>

                <div class="card card1">

                    <h2>👤</h2>

                    <p>
                        My Profile
                    </p>

                </div>


                <div class="card card2">

                    <h2>💰</h2>

                    <p>
                        My Salary
                    </p>

                </div>


                <div class="card card3">

                    <h2>📅</h2>

                    <p>
                        My Attendance
                    </p>

                </div>


                <div class="card card4">

                    <h2>📝</h2>

                    <p>
                        Leave
                    </p>

                </div>

            <% } %>

        </div>


        <!-- ================= INFORMATION SECTION ================= -->

        <div class="employee-section">


            <!-- ADMIN INFORMATION -->

            <% if ("admin".equalsIgnoreCase(role)) { %>

                <h2>
                    🛠 Admin Dashboard
                </h2>

                <p>
                    You are logged in as an administrator.
                    You can manage employees, salary,
                    attendance, leaves and reports.
                </p>


            <!-- EMPLOYEE INFORMATION -->

            <% } else if ("employee".equalsIgnoreCase(role)) { %>

                <h2>
                    👨‍💼 Employee Dashboard
                </h2>

                <p>
                    Welcome to your employee dashboard.
                    You can view your profile, salary,
                    attendance and apply for leave.
                </p>

            <% } %>


        </div>

    </div>

</body>

</html>