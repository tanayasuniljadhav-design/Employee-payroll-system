<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Leave Application - Employee Management Portal</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    min-height: 100vh;
    background: linear-gradient(135deg, #0d47a1, #1976d2, #42a5f5);
    padding: 30px 15px;
    color: #263238;
}

/* Top Header */

.header {
    max-width: 950px;
    margin: 0 auto 25px auto;
    background: linear-gradient(135deg, #0b3d91, #1565c0);
    color: white;
    padding: 20px 25px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.25);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.brand {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 50px;
    height: 50px;
    background: white;
    color: #0d47a1;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
    font-size: 20px;
}

.brand h1 {
    font-size: 21px;
}

.brand p {
    font-size: 12px;
    margin-top: 4px;
    opacity: 0.85;
}

.dashboard-btn {
    color: white;
    text-decoration: none;
    padding: 10px 16px;
    border: 1px solid rgba(255,255,255,0.5);
    border-radius: 8px;
    font-size: 14px;
    transition: 0.3s;
}

.dashboard-btn:hover {
    background: white;
    color: #0d47a1;
}

/* Main Container */

.container {
    max-width: 700px;
    margin: auto;
    background: rgba(255,255,255,0.97);
    padding: 35px;
    border-radius: 18px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}

/* Title */

.title-section {
    text-align: center;
    margin-bottom: 30px;
}

.title-icon {
    width: 65px;
    height: 65px;
    margin: auto;
    margin-bottom: 12px;
    background: #e3f2fd;
    color: #1565c0;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 28px;
}

.title-section h2 {
    color: #0d47a1;
    font-size: 27px;
    margin-bottom: 7px;
}

.title-section p {
    color: #78909c;
    font-size: 14px;
}

/* Form */

.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.full-width {
    grid-column: 1 / 3;
}

label {
    font-size: 14px;
    font-weight: bold;
    color: #37474f;
    margin-bottom: 7px;
}

.required {
    color: #e53935;
}

input,
select,
textarea {
    width: 100%;
    padding: 13px;
    border: 1px solid #cfd8dc;
    border-radius: 8px;
    font-size: 14px;
    outline: none;
    transition: 0.3s;
    background: #fafcff;
}

input:focus,
select:focus,
textarea:focus {
    border-color: #1976d2;
    box-shadow: 0 0 0 3px rgba(25,118,210,0.12);
    background: white;
}

textarea {
    min-height: 110px;
    resize: vertical;
}

/* Leave Type */

select {
    cursor: pointer;
}

/* Buttons */

.button-group {
    display: flex;
    gap: 12px;
    margin-top: 25px;
}

button {
    flex: 1;
    padding: 14px;
    border: none;
    border-radius: 9px;
    font-size: 15px;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
}

.submit-btn {
    background: linear-gradient(135deg, #1565c0, #1976d2);
    color: white;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 18px rgba(21,101,192,0.35);
}

.clear-btn {
    background: #eceff1;
    color: #37474f;
}

.clear-btn:hover {
    background: #cfd8dc;
}

/* Information Box */

.info-box {
    margin-top: 25px;
    padding: 15px;
    background: #e3f2fd;
    border-left: 4px solid #1976d2;
    border-radius: 7px;
    font-size: 13px;
    color: #455a64;
    line-height: 1.6;
}

/* Responsive */

@media (max-width: 700px) {

    .header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }

    .brand {
        flex-direction: column;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .full-width {
        grid-column: 1;
    }

    .container {
        padding: 25px 20px;
    }

    .button-group {
        flex-direction: column;
    }
}

</style>

<script>

function validateLeaveForm() {

    var empId = document.getElementsByName("empId")[0].value;
    var fromDate = document.getElementsByName("fromDate")[0].value;
    var toDate = document.getElementsByName("toDate")[0].value;
    var reason = document.getElementsByName("reason")[0].value.trim();

    if (empId <= 0) {
        alert("Please enter a valid Employee ID.");
        return false;
    }

    if (fromDate === "") {
        alert("Please select From Date.");
        return false;
    }

    if (toDate === "") {
        alert("Please select To Date.");
        return false;
    }

    if (new Date(toDate) < new Date(fromDate)) {
        alert("To Date cannot be earlier than From Date.");
        return false;
    }

    if (reason.length < 5) {
        alert("Please enter a proper reason for leave.");
        return false;
    }

    return confirm("Are you sure you want to submit this leave application?");
}

function clearForm() {
    document.getElementById("leaveForm").reset();
}

</script>

</head>

<body>

<!-- Header -->

<div class="header">

    <div class="brand">

        <div class="logo">
            AP
        </div>

        <div>
            <h1>Accenture plc</h1>
            <p>Employee Management Portal</p>
        </div>

    </div>

    <a href="dashboard.jsp" class="dashboard-btn">
        ← Dashboard
    </a>

</div>


<!-- Leave Application -->

<div class="container">

    <div class="title-section">

        <div class="title-icon">
            📅
        </div>

        <h2>Leave Application</h2>

        <p>Submit your employee leave request</p>

    </div>


    <form id="leaveForm"
          action="LeaveServlet"
          method="post"
          onsubmit="return validateLeaveForm()">

        <div class="form-grid">

            <!-- Employee ID -->

            <div class="form-group">

                <label>
                    Employee ID <span class="required">*</span>
                </label>

                <input type="number"
                       name="empId"
                       placeholder="Enter Employee ID"
                       min="1"
                       required>

            </div>


            <!-- Leave Type -->

            <div class="form-group">

                <label>
                    Leave Type <span class="required">*</span>
                </label>

                <select name="leaveType" required>

                    <option>Sick Leave</option>
                    <option>Casual Leave</option>
                    <option>Earned Leave</option>
                    <option>Maternity Leave</option>

                </select>

            </div>


            <!-- From Date -->

            <div class="form-group">

                <label>
                    From Date <span class="required">*</span>
                </label>

                <input type="date"
                       id="fromDate"
                       name="fromDate"
                       required>

            </div>


            <!-- To Date -->

            <div class="form-group">

                <label>
                    To Date <span class="required">*</span>
                </label>

                <input type="date"
                       id="toDate"
                       name="toDate"
                       required>

            </div>


            <!-- Reason -->

            <div class="form-group full-width">

                <label>
                    Reason for Leave <span class="required">*</span>
                </label>

                <textarea
                    name="reason"
                    placeholder="Enter the reason for your leave..."
                    required></textarea>

            </div>

        </div>


        <!-- Buttons -->

        <div class="button-group">

            <button type="button"
                    class="clear-btn"
                    onclick="clearForm()">
                Clear
            </button>

            <button type="submit"
                    class="submit-btn">
                Apply Leave
            </button>

        </div>

    </form>


    <div class="info-box">
        <strong>Note:</strong>
        Please select valid leave dates and provide a proper reason
        before submitting your application.
    </div>

</div>


<script>

/* Prevent selecting an invalid date range */

document.getElementById("fromDate").addEventListener("change", function() {

    document.getElementById("toDate").min = this.value;

});

</script>

</body>

</html>