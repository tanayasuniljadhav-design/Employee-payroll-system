<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>500 - Internal Server Error | Accenture Employee Management</title>

<style>

/* =========================================================
   GLOBAL RESET
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

html{
    scroll-behavior:smooth;
}

body{

    min-height:100vh;

    font-family:
        "Segoe UI",
        Arial,
        Helvetica,
        sans-serif;

    color:#263238;

    background:
        radial-gradient(
            circle at 15% 20%,
            rgba(33,150,243,0.20),
            transparent 30%
        ),
        radial-gradient(
            circle at 85% 80%,
            rgba(21,101,192,0.18),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #e3f2fd,
            #f5f9ff,
            #dbeafe
        );

    display:flex;

    align-items:center;

    justify-content:center;

    overflow:hidden;

    position:relative;
}


/* =========================================================
   BACKGROUND DECORATION
========================================================= */

.background-circle{

    position:absolute;

    border-radius:50%;

    pointer-events:none;

    opacity:0.45;
}

.circle-one{

    width:280px;
    height:280px;

    background:#bbdefb;

    top:-120px;
    left:-100px;
}

.circle-two{

    width:220px;
    height:220px;

    background:#90caf9;

    bottom:-100px;
    right:-80px;
}

.circle-three{

    width:90px;
    height:90px;

    background:#e3f2fd;

    top:18%;
    right:12%;
}


/* =========================================================
   MAIN WRAPPER
========================================================= */

.error-wrapper{

    width:92%;

    max-width:650px;

    text-align:center;

    position:relative;

    z-index:2;

    animation:
        pageAppear 0.6s ease;
}


/* =========================================================
   ERROR CARD
========================================================= */

.error-card{

    background:
        rgba(255,255,255,0.96);

    padding:
        45px 45px 40px;

    border-radius:24px;

    border:
        1px solid rgba(21,101,192,0.10);

    box-shadow:
        0 20px 50px rgba(13,71,161,0.17);

    backdrop-filter:blur(8px);

    position:relative;

    overflow:hidden;
}


/* Top blue line */

.error-card::before{

    content:"";

    position:absolute;

    top:0;
    left:0;

    width:100%;

    height:5px;

    background:
        linear-gradient(
            90deg,
            #0d47a1,
            #1976d2,
            #42a5f5
        );
}


/* =========================================================
   COMPANY BRAND
========================================================= */

.brand{

    display:flex;

    flex-direction:column;

    align-items:center;

    margin-bottom:24px;
}

.logo{

    width:58px;
    height:58px;

    border-radius:14px;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #0d47a1
        );

    color:white;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:20px;

    font-weight:800;

    box-shadow:
        0 8px 18px rgba(21,101,192,0.28);

    margin-bottom:10px;
}

.company-name{

    font-size:17px;

    font-weight:700;

    color:#0d47a1;
}

.portal-name{

    font-size:11px;

    color:#78909c;

    margin-top:2px;
}


/* =========================================================
   ERROR ICON
========================================================= */

.error-icon{

    width:100px;
    height:100px;

    margin:
        5px auto 20px;

    border-radius:50%;

    background:
        linear-gradient(
            135deg,
            #ffebee,
            #ffcdd2
        );

    color:#c62828;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:48px;

    font-weight:800;

    border:
        6px solid #fff;

    box-shadow:
        0 0 0 2px #ffcdd2,
        0 8px 20px rgba(198,40,40,0.12);

    animation:
        iconPulse 2s infinite;
}


/* =========================================================
   ERROR CODE
========================================================= */

.error-code{

    color:#0d47a1;

    font-size:64px;

    line-height:1;

    font-weight:800;

    letter-spacing:2px;

    margin-bottom:8px;
}


/* =========================================================
   ERROR TITLE
========================================================= */

h2{

    color:#263238;

    font-size:25px;

    font-weight:700;

    margin-bottom:12px;
}


/* =========================================================
   MESSAGE
========================================================= */

.message{

    max-width:480px;

    margin:
        0 auto 27px;

    color:#607d8b;

    font-size:14px;

    line-height:1.7;
}


/* =========================================================
   ACTIONS
========================================================= */

.actions{

    display:flex;

    justify-content:center;

    align-items:center;

    gap:10px;

    flex-wrap:wrap;
}


/* =========================================================
   DASHBOARD BUTTON
========================================================= */

.home-btn{

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    text-decoration:none;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #0d47a1
        );

    color:white;

    padding:
        13px 24px;

    min-width:180px;

    border-radius:9px;

    font-size:14px;

    font-weight:600;

    box-shadow:
        0 6px 16px rgba(21,101,192,0.25);

    transition:
        transform 0.25s ease,
        box-shadow 0.25s ease;
}

.home-btn:hover{

    color:white;

    transform:
        translateY(-3px);

    box-shadow:
        0 10px 22px rgba(13,71,161,0.32);
}


/* =========================================================
   HELP TEXT
========================================================= */

.help-text{

    margin-top:20px;

    font-size:12px;

    color:#90a4ae;
}


/* =========================================================
   FOOTER
========================================================= */

.footer{

    margin-top:18px;

    color:#607d8b;

    font-size:11px;

    line-height:1.6;
}


/* =========================================================
   ANIMATIONS
========================================================= */

@keyframes pageAppear{

    from{

        opacity:0;

        transform:
            translateY(25px)
            scale(0.98);
    }

    to{

        opacity:1;

        transform:
            translateY(0)
            scale(1);
    }
}


@keyframes iconPulse{

    0%,
    100%{

        transform:scale(1);

    }

    50%{

        transform:scale(1.04);

    }
}


/* =========================================================
   TABLET
========================================================= */

@media(max-width:700px){

    .error-card{

        padding:
            40px 30px 32px;
    }

    .error-code{

        font-size:56px;
    }

    h2{

        font-size:22px;
    }

}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width:500px){

    body{

        padding:20px;

    }

    .error-wrapper{

        width:100%;

    }

    .error-card{

        padding:
            38px 20px 28px;

        border-radius:18px;

    }

    .logo{

        width:50px;

        height:50px;

        font-size:17px;

    }

    .company-name{

        font-size:15px;

    }

    .portal-name{

        font-size:10px;

    }

    .error-icon{

        width:80px;

        height:80px;

        font-size:38px;

        margin-bottom:17px;

    }

    .error-code{

        font-size:48px;

    }

    h2{

        font-size:20px;

    }

    .message{

        font-size:13px;

    }

    .home-btn{

        width:100%;

    }

}


/* =========================================================
   VERY SMALL DEVICES
========================================================= */

@media(max-width:350px){

    .error-card{

        padding:
            32px 15px 25px;

    }

    .error-code{

        font-size:42px;

    }

    h2{

        font-size:18px;

    }

}

</style>

</head>


<body>


<!-- =====================================================
     BACKGROUND DECORATION
===================================================== -->

<div class="background-circle circle-one"></div>

<div class="background-circle circle-two"></div>

<div class="background-circle circle-three"></div>


<!-- =====================================================
     ERROR PAGE
===================================================== -->

<div class="error-wrapper">


    <div class="error-card">


        <!-- COMPANY BRAND -->

        <div class="brand">

            <div class="logo">
                AP
            </div>

            <div class="company-name">
                Accenture plc
            </div>

            <div class="portal-name">
                Employee Management Portal
            </div>

        </div>


        <!-- ERROR ICON -->

        <div class="error-icon">
            !
        </div>


        <!-- ERROR CODE -->

        <div class="error-code">
            500
        </div>


        <!-- ERROR TITLE -->

        <h2>
            Internal Server Error
        </h2>


        <!-- ERROR MESSAGE -->

        <p class="message">

            Something went wrong while processing your request.
            The server could not complete the operation.
            Please try again or return to the Employee Management Dashboard.

        </p>


        <!-- ACTION -->

        <div class="actions">

            <a
                href="dashboard.jsp"
                class="home-btn">

                ← Go to Dashboard

            </a>

        </div>


        <!-- HELP -->

        <div class="help-text">

            If the problem continues, please contact the system administrator.

        </div>


    </div>


    <!-- FOOTER -->

    <div class="footer">

        © 2026 Accenture plc
        <br>
        Employee Payroll & Management System

    </div>


</div>


</body>

</html>