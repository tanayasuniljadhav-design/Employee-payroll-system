
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@page import="java.util.*"%>
<%@page import="model.Attendance"%>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Accenture | Attendance Report</title>


<style>

/* =========================
   GLOBAL
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family: Arial, Helvetica, sans-serif;

    background:
        linear-gradient(
            135deg,
            #e3f2fd,
            #f3e5f5,
            #eef7f1
        );

    min-height: 100vh;

    color: #263238;
}


/* =========================
   HEADER
========================= */

.header {

    width: 100%;

    height: 72px;

    background:
        linear-gradient(
            135deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 4px 15px rgba(0,0,0,0.15);
}


/* Logo */

.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 43px;

    height: 43px;

    border-radius: 10px;

    background: white;

    color: #0d47a1;

    display: flex;

    align-items: center;

    justify-content: center;

    font-weight: bold;

    font-size: 18px;
}


.company-name {

    font-size: 20px;

    font-weight: bold;
}


.portal-name {

    font-size: 11px;

    opacity: 0.8;

    margin-top: 3px;
}


/* Back button */

.back-btn {

    text-decoration: none;

    color: white;

    background:
        rgba(255,255,255,0.15);

    padding: 10px 18px;

    border-radius: 8px;

    font-size: 14px;

    transition: 0.3s;
}

.back-btn:hover {

    background:
        rgba(255,255,255,0.28);

    transform: translateY(-2px);
}


/* =========================
   MAIN CONTENT
========================= */

.content {

    padding: 35px;

    max-width: 1400px;

    margin: auto;
}


/* =========================
   PAGE TITLE
========================= */

.page-heading {

    margin-bottom: 25px;
}

.page-heading h1 {

    font-size: 28px;

    color: #102a43;

    margin-bottom: 7px;
}

.page-heading p {

    font-size: 14px;

    color: #78909c;
}


/* =========================
   SUMMARY CARDS
========================= */

.summary {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 20px;

    margin-bottom: 25px;
}


.summary-card {

    background: white;

    border-radius: 14px;

    padding: 20px;

    display: flex;

    align-items: center;

    gap: 15px;

    box-shadow:
        0 6px 20px rgba(0,0,0,0.07);

    border-left: 5px solid #1976d2;
}


.summary-icon {

    width: 48px;

    height: 48px;

    border-radius: 11px;

    background: #e3f2fd;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 22px;
}


.summary-title {

    font-size: 12px;

    color: #78909c;

    margin-bottom: 5px;
}


.summary-number {

    font-size: 22px;

    font-weight: bold;

    color: #102a43;
}


/* =========================
   REPORT CARD
========================= */

.report-card {

    background: white;

    border-radius: 16px;

    box-shadow:
        0 8px 25px rgba(0,0,0,0.08);

    overflow: hidden;
}


/* Report header */

.report-header {

    padding: 22px 25px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    border-bottom: 1px solid #eceff1;
}


.report-header h2 {

    color: #102a43;

    font-size: 20px;
}


.report-header p {

    color: #78909c;

    font-size: 12px;

    margin-top: 5px;
}


/* =========================
   FILTER AREA
========================= */

.filter-area {

    padding: 18px 25px;

    background: #f8fafc;

    border-bottom:
        1px solid #eceff1;

    display: flex;

    gap: 12px;

    flex-wrap: wrap;
}


.search-box {

    flex: 1;

    min-width: 220px;

    position: relative;
}


.search-box input {

    width: 100%;

    padding: 11px 14px 11px 40px;

    border: 1px solid #cfd8dc;

    border-radius: 8px;

    outline: none;

    font-size: 13px;

    background: white;
}


.search-box input:focus {

    border-color: #1976d2;

    box-shadow:
        0 0 0 3px
        rgba(25,118,210,0.10);
}


.search-icon {

    position: absolute;

    left: 13px;

    top: 50%;

    transform: translateY(-50%);

    font-size: 15px;
}


.filter-select {

    padding: 11px 14px;

    border: 1px solid #cfd8dc;

    border-radius: 8px;

    background: white;

    outline: none;

    font-size: 13px;

    min-width: 150px;
}


/* =========================
   TABLE
========================= */

.table-container {

    width: 100%;

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 650px;
}


thead {

    background:
        linear-gradient(
            135deg,
            #1976d2,
            #1565c0
        );
}


th {

    color: white;

    padding: 15px 12px;

    font-size: 13px;

    text-align: center;

    white-space: nowrap;
}


td {

    padding: 14px 12px;

    text-align: center;

    font-size: 13px;

    color: #455a64;

    border-bottom:
        1px solid #eceff1;
}


tbody tr {

    transition: 0.2s;
}


tbody tr:hover {

    background: #f4f9ff;
}


/* Attendance ID */

.id-badge {

    background: #e3f2fd;

    color: #1565c0;

    padding: 5px 9px;

    border-radius: 6px;

    font-weight: bold;

    font-size: 12px;
}


/* Employee ID */

.emp-badge {

    background: #f3e5f5;

    color: #6a1b9a;

    padding: 5px 9px;

    border-radius: 6px;

    font-weight: bold;

    font-size: 12px;
}


/* =========================
   STATUS BADGES
========================= */

.status {

    display: inline-block;

    padding: 6px 13px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: bold;
}


.status-present {

    background: #e8f5e9;

    color: #2e7d32;
}


.status-absent {

    background: #ffebee;

    color: #c62828;
}


.status-leave {

    background: #fff3e0;

    color: #ef6c00;
}


/* =========================
   NO DATA
========================= */

.no-data {

    padding: 50px 20px;

    text-align: center;

    color: #78909c;
}


.no-data-icon {

    font-size: 45px;

    margin-bottom: 12px;
}


.no-data h3 {

    color: #455a64;

    margin-bottom: 6px;
}


/* =========================
   FOOTER
========================= */

.footer {

    text-align: center;

    padding: 20px;

    color: #90a4ae;

    font-size: 12px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 800px) {

    .content {

        padding: 25px 15px;
    }

    .summary {

        grid-template-columns: 1fr;
    }

    .header {

        padding: 0 15px;
    }

    .company-name {

        font-size: 16px;
    }

    .portal-name {

        display: none;
    }

}

</style>

</head>


<body>


<!-- =========================
     HEADER
========================= -->

<div class="header">

    <div class="logo-area">

        <div class="logo">
            AP
        </div>

        <div>

            <div class="company-name">
                Accenture plc
            </div>

            <div class="portal-name">
                Employee Management Portal
            </div>

        </div>

    </div>


    <a href="dashboard.jsp"
       class="back-btn">

        ← Back to Dashboard

    </a>

</div>



<!-- =========================
     MAIN CONTENT
========================= -->

<div class="content">


    <!-- PAGE HEADING -->

    <div class="page-heading">

        <h1>
            Attendance Report
        </h1>

        <p>
            View and monitor employee attendance records
            from the payroll management system.
        </p>

    </div>



    <!-- =========================
         SUMMARY
    ========================= -->

    <div class="summary">


        <div class="summary-card">

            <div class="summary-icon">
                📋
            </div>

            <div>

                <div class="summary-title">
                    Total Records
                </div>

                <div class="summary-number"
                     id="totalRecords">

                    0

                </div>

            </div>

        </div>



        <div class="summary-card">

            <div class="summary-icon">
                👤
            </div>

            <div>

                <div class="summary-title">
                    Present
                </div>

                <div class="summary-number"
                     id="presentRecords">

                    0

                </div>

            </div>

        </div>



        <div class="summary-card">

            <div class="summary-icon">
                📝
            </div>

            <div>

                <div class="summary-title">
                    Other Records
                </div>

                <div class="summary-number"
                     id="otherRecords">

                    0

                </div>

            </div>

        </div>


    </div>



    <!-- =========================
         REPORT CARD
    ========================= -->

    <div class="report-card">


        <div class="report-header">

            <div>

                <h2>
                    Employee Attendance Records
                </h2>

                <p>
                    Attendance history
                </p>

            </div>

        </div>



        <!-- =========================
             FILTER
        ========================= -->

        <div class="filter-area">


            <div class="search-box">

                <span class="search-icon">
                    🔍
                </span>

                <input
                    type="text"
                    id="searchInput"
                    placeholder="Search by Employee ID..."
                    onkeyup="filterTable()">

            </div>


            <select
                class="filter-select"
                id="statusFilter"
                onchange="filterTable()">

                <option value="all">
                    All Status
                </option>

                <option value="Present">
                    Present
                </option>

                <option value="Absent">
                    Absent
                </option>

                <option value="Leave">
                    Leave
                </option>

            </select>


        </div>



        <!-- =========================
             TABLE
        ========================= -->

        <div class="table-container">

        <table id="attendanceTable">


            <thead>

                <tr>

                    <th>
                        Attendance ID
                    </th>

                    <th>
                        Employee ID
                    </th>

                    <th>
                        Date
                    </th>

                    <th>
                        Status
                    </th>

                </tr>

            </thead>


            <tbody>


<%

ArrayList<Attendance> list =
    (ArrayList<Attendance>)
    request.getAttribute("attendanceList");

if(list != null && !list.isEmpty()) {

    for(Attendance a : list) {

%>


                <tr>

                    <td>

                        <span class="id-badge">

                            <%=a.getAttendanceId()%>

                        </span>

                    </td>


                    <td>

                        <span class="emp-badge">

                            <%=a.getEmpId()%>

                        </span>

                    </td>


                    <td>

                        <%=a.getAttendanceDate()%>

                    </td>


                    <td>

                        <%

                        String status =
                            a.getStatus();

                        String statusClass =
                            "status-present";

                        if("Absent".equalsIgnoreCase(status)) {

                            statusClass =
                                "status-absent";

                        } else if("Leave".equalsIgnoreCase(status)) {

                            statusClass =
                                "status-leave";

                        }

                        %>


                        <span class="status <%=statusClass%>">

                            <%=status%>

                        </span>


                    </td>

                </tr>


<%

    }

} else {

%>


                <tr>

                    <td colspan="4">

                        <div class="no-data">

                            <div class="no-data-icon">
                                📋
                            </div>

                            <h3>
                                No Attendance Records
                            </h3>

                            <p>
                                There are currently no
                                attendance records available.
                            </p>

                        </div>

                    </td>

                </tr>


<%

}

%>


            </tbody>


        </table>

        </div>


    </div>


</div>



<!-- =========================
     FOOTER
========================= -->

<div class="footer">

    © 2026 Accenture Employee Management Portal

</div>



<!-- =========================
     INTERNAL JAVASCRIPT
========================= -->

<script>

/* =========================
   FILTER TABLE
========================= */

function filterTable() {

    var searchInput =
        document.getElementById("searchInput")
        .value
        .toLowerCase();

    var statusFilter =
        document.getElementById("statusFilter")
        .value;

    var table =
        document.getElementById("attendanceTable");

    var rows =
        table.getElementsByTagName("tbody")[0]
        .getElementsByTagName("tr");


    for(var i = 0; i < rows.length; i++) {

        var cells =
            rows[i].getElementsByTagName("td");


        /* Ignore no-data row */

        if(cells.length < 4) {

            continue;

        }


        var employeeId =
            cells[1]
            .innerText
            .toLowerCase();

        var status =
            cells[3]
            .innerText
            .trim();


        var matchesSearch =
            employeeId.includes(searchInput);


        var matchesStatus =
            statusFilter === "all" ||
            status === statusFilter;


        if(matchesSearch && matchesStatus) {

            rows[i].style.display = "";

        } else {

            rows[i].style.display = "none";

        }

    }

}


/* =========================
   CALCULATE SUMMARY
========================= */

window.onload = function() {

    var table =
        document.getElementById("attendanceTable");

    var rows =
        table.getElementsByTagName("tbody")[0]
        .getElementsByTagName("tr");


    var total = 0;

    var present = 0;

    var other = 0;


    for(var i = 0; i < rows.length; i++) {

        var cells =
            rows[i].getElementsByTagName("td");


        if(cells.length < 4) {

            continue;

        }


        total++;


        var status =
            cells[3]
            .innerText
            .trim();


        if(status === "Present") {

            present++;

        } else {

            other++;

        }

    }


    document.getElementById(
        "totalRecords"
    ).innerText = total;


    document.getElementById(
        "presentRecords"
    ).innerText = present;


    document.getElementById(
        "otherRecords"
    ).innerText = other;

};

</script>


</body>

</html>

