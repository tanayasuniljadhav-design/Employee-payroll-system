
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Accenture | Attendance Management</title>

<style>

/* =========================
   GLOBAL
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family: Arial, Helvetica, sans-serif;

    min-height: 100vh;

    background:
        linear-gradient(
            135deg,
            #e3f2fd,
            #ede7f6,
            #e8f5e9
        );

    color: #263238;
}


/* =========================
   HEADER
========================= */

.header {

    height: 72px;

    width: 100%;

    background:
        linear-gradient(
            135deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 4px 15px rgba(0,0,0,0.15);
}


/* Logo */

.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;
}

.logo {

    width: 43px;

    height: 43px;

    background: white;

    color: #0d47a1;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

    font-weight: bold;
}


.company-name {

    font-size: 20px;

    font-weight: bold;
}


.portal-name {

    font-size: 11px;

    opacity: 0.8;

    margin-top: 3px;
}


/* Back button */

.back-btn {

    color: white;

    text-decoration: none;

    padding: 10px 18px;

    background:
        rgba(255,255,255,0.15);

    border-radius: 8px;

    font-size: 14px;

    transition: 0.3s;
}

.back-btn:hover {

    background:
        rgba(255,255,255,0.28);

    transform: translateY(-2px);
}


/* =========================
   MAIN PAGE
========================= */

.page {

    min-height:
        calc(100vh - 72px);

    display: flex;

    justify-content: center;

    align-items: flex-start;

    padding: 45px 20px;
}


/* =========================
   ATTENDANCE CARD
========================= */

.container {

    width: 100%;

    max-width: 620px;

    background: white;

    border-radius: 18px;

    overflow: hidden;

    box-shadow:
        0 12px 35px rgba(0,0,0,0.12);
}


/* =========================
   CARD HEADER
========================= */

.form-header {

    background:
        linear-gradient(
            135deg,
            #1976d2,
            #0d47a1
        );

    color: white;

    padding: 28px 30px;
}


.header-icon {

    width: 48px;

    height: 48px;

    border-radius: 12px;

    background:
        rgba(255,255,255,0.18);

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 23px;

    margin-bottom: 14px;
}


.form-header h1 {

    font-size: 25px;

    margin-bottom: 7px;
}


.form-header p {

    font-size: 13px;

    opacity: 0.85;

    line-height: 1.5;
}


/* =========================
   FORM
========================= */

.form-body {

    padding: 30px;
}


.section-title {

    font-size: 17px;

    font-weight: bold;

    color: #102a43;

    padding-bottom: 11px;

    margin-bottom: 22px;

    border-bottom:
        2px solid #e3f2fd;
}


.form-group {

    margin-bottom: 20px;
}


label {

    display: block;

    font-size: 13px;

    font-weight: bold;

    color: #455a64;

    margin-bottom: 8px;
}


.input-wrapper {

    position: relative;
}


.input-icon {

    position: absolute;

    left: 13px;

    top: 50%;

    transform: translateY(-50%);

    font-size: 17px;
}


input,
select {

    width: 100%;

    padding: 13px 14px 13px 42px;

    border:
        1px solid #cfd8dc;

    border-radius: 9px;

    background: #fafcff;

    color: #263238;

    font-size: 14px;

    outline: none;

    transition: 0.25s;
}


input:focus,
select:focus {

    background: white;

    border-color: #1976d2;

    box-shadow:
        0 0 0 3px
        rgba(25,118,210,0.10);
}


input:hover,
select:hover {

    border-color: #90caf9;
}


/* =========================
   STATUS
========================= */

.status-section {

    margin-top: 8px;

    margin-bottom: 25px;
}


.status-label {

    display: block;

    font-size: 13px;

    font-weight: bold;

    color: #455a64;

    margin-bottom: 8px;
}


.status-select {

    padding-left: 42px;
}


/* =========================
   INFO BOX
========================= */

.info-box {

    background: #e3f2fd;

    border-left:
        4px solid #1976d2;

    padding: 13px 15px;

    border-radius: 6px;

    font-size: 12px;

    color: #455a64;

    line-height: 1.6;

    margin-bottom: 25px;
}


/* =========================
   BUTTON
========================= */

.button-area {

    display: flex;

    justify-content: flex-end;

    gap: 12px;

    padding-top: 22px;

    border-top:
        1px solid #eceff1;
}


.clear-btn {

    padding: 12px 22px;

    border:
        1px solid #b0bec5;

    background: white;

    color: #455a64;

    border-radius: 8px;

    cursor: pointer;

    font-size: 14px;

    transition: 0.3s;
}


.clear-btn:hover {

    background: #eceff1;
}


.save-btn {

    padding: 12px 28px;

    border: none;

    border-radius: 8px;

    background:
        linear-gradient(
            135deg,
            #1976d2,
            #0d47a1
        );

    color: white;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;

    transition: 0.3s;
}


.save-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 6px 15px
        rgba(13,71,161,0.25);
}


/* =========================
   FOOTER
========================= */

.footer {

    text-align: center;

    color: #78909c;

    font-size: 12px;

    padding: 15px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 600px) {

    .header {

        padding: 0 15px;
    }

    .company-name {

        font-size: 16px;
    }

    .portal-name {

        display: none;
    }

    .form-body {

        padding: 22px;
    }

    .button-area {

        flex-direction: column;
    }

    .clear-btn,
    .save-btn {

        width: 100%;
    }

}

</style>

</head>


<body>


<!-- =========================
     HEADER
========================= -->

<div class="header">

    <div class="logo-area">

        <div class="logo">
            AP
        </div>

        <div>

            <div class="company-name">
                Accenture plc
            </div>

            <div class="portal-name">
                Employee Management Portal
            </div>

        </div>

    </div>


    <a href="dashboard.jsp"
       class="back-btn">

        ← Back to Dashboard

    </a>

</div>



<!-- =========================
     MAIN
========================= -->

<div class="page">


    <div class="container">


        <!-- HEADER -->

        <div class="form-header">

            <div class="header-icon">
                🕒
            </div>

            <h1>
                Mark Attendance
            </h1>

            <p>
                Record daily attendance for employees
                in the payroll management system.
            </p>

        </div>



        <!-- FORM BODY -->

        <div class="form-body">


            <div class="section-title">

                Attendance Information

            </div>



            <!-- IMPORTANT:
                 Existing servlet and parameters
                 are kept unchanged.
            -->

            <form
                action="AttendanceServlet"
                method="post"
                onsubmit="return validateAttendance();">


                <!-- Employee ID -->

                <div class="form-group">

                    <label for="empId">
                        Employee ID
                    </label>

                    <div class="input-wrapper">

                        <span class="input-icon">
                            👤
                        </span>

                        <input
                            type="number"
                            id="empId"
                            name="empId"
                            placeholder="Enter employee ID"
                            min="1"
                            required>

                    </div>

                </div>



                <!-- Date -->

                <div class="form-group">

                    <label for="date">
                        Attendance Date
                    </label>

                    <div class="input-wrapper">

                        <span class="input-icon">
                            📅
                        </span>

                        <input
                            type="date"
                            id="date"
                            name="date"
                            required>

                    </div>

                </div>



                <!-- Status -->

                <div class="status-section">

                    <label
                        for="status"
                        class="status-label">

                        Attendance Status

                    </label>

                    <div class="input-wrapper">

                        <span class="input-icon">
                            📋
                        </span>

                        <select
                            id="status"
                            name="status"
                            class="status-select"
                            required>

                            <option value="Present">
                                Present
                            </option>

                            <option value="Absent">
                                Absent
                            </option>

                            <option value="Leave">
                                Leave
                            </option>

                        </select>

                    </div>

                </div>



                <!-- INFORMATION -->

                <div class="info-box">

                    <strong>Attendance Note:</strong>

                    Please verify the employee ID,
                    attendance date and status before
                    saving the attendance record.

                </div>



                <!-- BUTTONS -->

                <div class="button-area">


                    <button
                        type="reset"
                        class="clear-btn">

                        Clear

                    </button>


                    <button
                        type="submit"
                        class="save-btn">

                        ✓ Save Attendance

                    </button>


                </div>


            </form>


        </div>


    </div>

</div>



<!-- =========================
     FOOTER
========================= -->

<div class="footer">

    © 2026 Accenture Employee Management Portal

</div>



<!-- =========================
     INTERNAL JAVASCRIPT
========================= -->

<script>

function validateAttendance() {

    var empId =
        document.getElementById("empId").value;

    var date =
        document.getElementById("date").value;

    var status =
        document.getElementById("status").value;


    /* Employee ID validation */

    if (empId === "" || empId <= 0) {

        alert(
            "Please enter a valid Employee ID."
        );

        return false;
    }


    /* Date validation */

    if (date === "") {

        alert(
            "Please select the attendance date."
        );

        return false;
    }


    /* Status validation */

    if (status === "") {

        alert(
            "Please select an attendance status."
        );

        return false;
    }


    return true;

}


/* Set today's date automatically */

window.onload = function() {

    var dateField =
        document.getElementById("date");

    if (dateField.value === "") {

        var today =
            new Date();

        var year =
            today.getFullYear();

        var month =
            String(
                today.getMonth() + 1
            ).padStart(2, "0");

        var day =
            String(
                today.getDate()
            ).padStart(2, "0");

        dateField.value =
            year + "-" + month + "-" + day;
    }

};

</script>


</body>

</html>

