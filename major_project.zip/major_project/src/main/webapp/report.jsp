<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Employee Payroll Reports</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    min-height: 100vh;

    background:
        radial-gradient(circle at 10% 10%, rgba(66,165,245,0.25), transparent 30%),
        radial-gradient(circle at 90% 90%, rgba(21,101,192,0.3), transparent 30%),
        linear-gradient(135deg, #0d47a1, #1976d2, #42a5f5);

    padding: 25px;
    color: #263238;
}

/* Header */

.header {
    max-width: 1200px;
    margin: 0 auto 25px auto;

    background: linear-gradient(135deg, #0b3d91, #1565c0);

    color: white;

    padding: 20px 25px;

    border-radius: 15px;

    box-shadow: 0 8px 25px rgba(0,0,0,0.25);

    display: flex;
    justify-content: space-between;
    align-items: center;
}

.brand {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 52px;
    height: 52px;

    background: white;
    color: #0d47a1;

    border-radius: 12px;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 20px;
    font-weight: bold;
}

.brand h1 {
    font-size: 22px;
}

.brand p {
    font-size: 13px;
    margin-top: 4px;
    opacity: 0.85;
}

/* Dashboard Button */

.dashboard-btn {
    color: white;
    text-decoration: none;

    padding: 10px 17px;

    border: 1px solid rgba(255,255,255,0.5);

    border-radius: 8px;

    font-size: 14px;

    transition: 0.3s;
}

.dashboard-btn:hover {
    background: white;
    color: #0d47a1;
}

/* Main Container */

.container {
    max-width: 1200px;
    margin: auto;
}

/* Page Title */

.title-section {
    background: rgba(255,255,255,0.97);

    padding: 28px;

    border-radius: 15px;

    text-align: center;

    box-shadow: 0 8px 25px rgba(0,0,0,0.18);

    margin-bottom: 25px;
}

.title-icon {
    width: 65px;
    height: 65px;

    margin: 0 auto 12px auto;

    background: #e3f2fd;
    color: #1565c0;

    border-radius: 50%;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 28px;
}

.title-section h2 {
    color: #0d47a1;
    font-size: 27px;
}

.title-section p {
    color: #78909c;
    font-size: 13px;
    margin-top: 7px;
}

/* Report Cards */

.report-grid {
    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 20px;
}

.card {
    position: relative;

    background: rgba(255,255,255,0.97);

    padding: 28px 20px;

    border-radius: 16px;

    text-align: center;

    box-shadow: 0 10px 25px rgba(0,0,0,0.18);

    overflow: hidden;

    transition: 0.3s;
}

.card:hover {
    transform: translateY(-7px);

    box-shadow: 0 17px 32px rgba(0,0,0,0.25);
}

/* Top Card Line */

.card::before {
    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 5px;

    background: linear-gradient(90deg, #0d47a1, #42a5f5);
}

/* Icons */

.card-icon {
    width: 60px;
    height: 60px;

    margin: 5px auto 15px auto;

    border-radius: 15px;

    background: #e3f2fd;
    color: #1565c0;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 27px;
}

/* Card Text */

.card h3 {
    color: #546e7a;

    font-size: 14px;

    font-weight: 600;

    margin-bottom: 12px;
}

.card h1 {
    color: #0d47a1;

    font-size: 31px;

    font-weight: bold;
}

/* Currency */

.currency {
    font-size: 20px;
    margin-right: 3px;
}

/* Card Description */

.card-description {
    color: #90a4ae;

    font-size: 11px;

    margin-top: 10px;
}

/* Quick Navigation */

.quick-actions {
    margin-top: 25px;

    background: rgba(255,255,255,0.97);

    padding: 22px;

    border-radius: 15px;

    box-shadow: 0 8px 25px rgba(0,0,0,0.16);

    text-align: center;
}

.quick-actions h3 {
    color: #0d47a1;

    margin-bottom: 15px;

    font-size: 17px;
}

.action-btn {
    display: inline-block;

    margin: 5px;

    padding: 10px 17px;

    border-radius: 8px;

    text-decoration: none;

    background: #e3f2fd;

    color: #1565c0;

    font-size: 13px;

    font-weight: bold;

    transition: 0.3s;
}

.action-btn:hover {
    background: #1565c0;
    color: white;
}

/* Footer */

.footer {
    text-align: center;

    color: rgba(255,255,255,0.85);

    font-size: 12px;

    margin-top: 22px;
}

/* Responsive */

@media (max-width: 1000px) {

    .report-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media (max-width: 700px) {

    body {
        padding: 15px;
    }

    .header {
        flex-direction: column;

        gap: 15px;

        text-align: center;
    }

    .brand {
        flex-direction: column;
    }

    .report-grid {
        grid-template-columns: 1fr;
    }

    .title-section h2 {
        font-size: 23px;
    }

}

</style>

</head>


<body>

<!-- Header -->

<div class="header">

    <div class="brand">

        <div class="logo">
            AP
        </div>

        <div>

            <h1>Accenture plc</h1>

            <p>
                Employee Management Portal
            </p>

        </div>

    </div>


    <a href="dashboard.jsp"
       class="dashboard-btn">

        ← Dashboard

    </a>

</div>


<!-- Main Content -->

<div class="container">


    <!-- Page Title -->

    <div class="title-section">

        <div class="title-icon">
            📊
        </div>

        <h2>
            Employee Payroll Reports
        </h2>

        <p>
            Overview of employee, attendance, payroll and leave information
        </p>

    </div>


    <!-- Report Cards -->

    <div class="report-grid">


        <!-- Total Employees -->

        <div class="card">

            <div class="card-icon">
                👥
            </div>

            <h3>
                Total Employees
            </h3>

            <h1>
                ${employeeCount}
            </h1>

            <div class="card-description">
                Employees registered in the system
            </div>

        </div>


        <!-- Present Employees -->

        <div class="card">

            <div class="card-icon">
                ✓
            </div>

            <h3>
                Present Employees
            </h3>

            <h1>
                ${presentCount}
            </h1>

            <div class="card-description">
                Employees marked present
            </div>

        </div>


        <!-- Salary Paid -->

        <div class="card">

            <div class="card-icon">
                💰
            </div>

            <h3>
                Total Salary Paid
            </h3>

            <h1>
                <span class="currency">₹</span>${salaryPaid}
            </h1>

            <div class="card-description">
                Total salary processed
            </div>

        </div>


        <!-- Leave Applications -->

        <div class="card">

            <div class="card-icon">
                📅
            </div>

            <h3>
                Total Leave Applications
            </h3>

            <h1>
                ${leaveCount}
            </h1>

            <div class="card-description">
                Leave applications recorded
            </div>

        </div>


    </div>


    <!-- Quick Actions -->

    <div class="quick-actions">

        <h3>
            Quick Reports
        </h3>

        <a href="ViewEmployeeServlet"
           class="action-btn">
            👥 Employee Report
        </a>

        <a href="AttendanceReportServlet"
           class="action-btn">
            ✓ Attendance Report
        </a>

        <a href="SalaryReportServlet"
           class="action-btn">
            💰 Salary Report
        </a>

        <a href="LeaveReportServlet"
           class="action-btn">
            📅 Leave Report
        </a>

    </div>


</div>


<div class="footer">

    Employee Payroll System • Employee Management Portal

</div>


</body>

</html>