<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.*"%>
<%@ page import="model.Leave"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Leave Report - Employee Management Portal</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    min-height: 100vh;
    background: linear-gradient(135deg, #0d47a1, #1565c0, #42a5f5);
    color: #263238;
    padding: 25px;
}

/* Header */

.header {
    max-width: 1250px;
    margin: 0 auto 25px auto;
    background: linear-gradient(135deg, #0b3d91, #1565c0);
    color: white;
    padding: 20px 25px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.25);

    display: flex;
    justify-content: space-between;
    align-items: center;
}

.brand {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 52px;
    height: 52px;
    border-radius: 12px;
    background: white;
    color: #0d47a1;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 20px;
    font-weight: bold;
}

.brand h1 {
    font-size: 22px;
}

.brand p {
    font-size: 13px;
    margin-top: 4px;
    opacity: 0.85;
}

.dashboard-btn {
    text-decoration: none;
    color: white;
    border: 1px solid rgba(255,255,255,0.5);
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 14px;
    transition: 0.3s;
}

.dashboard-btn:hover {
    background: white;
    color: #0d47a1;
}

/* Main Container */

.container {
    max-width: 1250px;
    margin: auto;
}

/* Title */

.page-title {
    background: rgba(255,255,255,0.96);
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 20px;

    display: flex;
    justify-content: space-between;
    align-items: center;

    box-shadow: 0 8px 25px rgba(0,0,0,0.18);
}

.title-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

.title-icon {
    width: 55px;
    height: 55px;
    background: #e3f2fd;
    color: #1565c0;
    border-radius: 50%;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 25px;
}

.page-title h2 {
    color: #0d47a1;
    font-size: 25px;
}

.page-title p {
    color: #78909c;
    font-size: 13px;
    margin-top: 5px;
}

/* Summary Cards */

.summary {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-bottom: 20px;
}

.summary-card {
    background: rgba(255,255,255,0.96);
    border-radius: 14px;
    padding: 20px;

    box-shadow: 0 7px 20px rgba(0,0,0,0.15);

    display: flex;
    align-items: center;
    gap: 15px;
}

.summary-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    background: #e3f2fd;
    color: #1565c0;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 21px;
}

.summary-card h3 {
    font-size: 24px;
    color: #263238;
}

.summary-card p {
    font-size: 12px;
    color: #78909c;
    margin-top: 3px;
}

/* Controls */

.controls {
    background: rgba(255,255,255,0.96);
    padding: 18px;
    border-radius: 14px;
    margin-bottom: 20px;

    display: flex;
    gap: 15px;
    align-items: center;

    box-shadow: 0 7px 20px rgba(0,0,0,0.15);
}

.search-box,
.filter-box {
    padding: 11px 13px;
    border: 1px solid #cfd8dc;
    border-radius: 8px;
    outline: none;
    font-size: 14px;
}

.search-box {
    flex: 1;
}

.search-box:focus,
.filter-box:focus {
    border-color: #1976d2;
    box-shadow: 0 0 0 3px rgba(25,118,210,0.1);
}

/* Table */

.table-container {
    background: rgba(255,255,255,0.97);
    padding: 20px;
    border-radius: 15px;

    box-shadow: 0 8px 25px rgba(0,0,0,0.18);

    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 950px;
}

thead th {
    background: linear-gradient(135deg, #0d47a1, #1565c0);
    color: white;
    padding: 14px 12px;
    text-align: center;
    font-size: 13px;
    white-space: nowrap;
}

tbody td {
    padding: 13px 10px;
    text-align: center;
    border-bottom: 1px solid #eceff1;
    font-size: 13px;
}

tbody tr {
    transition: 0.2s;
}

tbody tr:hover {
    background: #f1f8ff;
}

/* Leave Type Badge */

.leave-type {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 20px;
    background: #e3f2fd;
    color: #1565c0;
    font-weight: bold;
    font-size: 11px;
}

/* Status Badges */

.status {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}

.status-approved {
    background: #e8f5e9;
    color: #2e7d32;
}

.status-pending {
    background: #fff8e1;
    color: #f57f17;
}

.status-rejected {
    background: #ffebee;
    color: #c62828;
}

.status-default {
    background: #eceff1;
    color: #455a64;
}

/* Reason */

.reason {
    max-width: 220px;
    text-align: left !important;
    word-wrap: break-word;
    line-height: 1.5;
}

/* No Data */

.no-data {
    text-align: center;
    padding: 45px !important;
    color: #78909c;
    font-size: 15px;
}

.no-data-icon {
    display: block;
    font-size: 35px;
    margin-bottom: 10px;
}

/* Footer */

.footer {
    text-align: center;
    color: rgba(255,255,255,0.85);
    font-size: 12px;
    margin-top: 20px;
}

/* Responsive */

@media (max-width: 800px) {

    body {
        padding: 15px;
    }

    .header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }

    .brand {
        flex-direction: column;
    }

    .page-title {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }

    .title-left {
        flex-direction: column;
    }

    .summary {
        grid-template-columns: 1fr;
    }

    .controls {
        flex-direction: column;
        align-items: stretch;
    }

    .search-box,
    .filter-box {
        width: 100%;
    }
}

</style>

<script>

/* Search and filter */

function filterLeaveReport() {

    var searchInput =
        document.getElementById("searchEmployee").value.toLowerCase();

    var statusFilter =
        document.getElementById("statusFilter").value.toLowerCase();

    var rows =
        document.querySelectorAll("#leaveTable tbody tr.data-row");

    rows.forEach(function(row) {

        var employeeId =
            row.cells[1].innerText.toLowerCase();

        var status =
            row.cells[6].innerText.toLowerCase();

        var employeeMatch =
            employeeId.includes(searchInput);

        var statusMatch =
            statusFilter === "all" ||
            status.includes(statusFilter);

        if (employeeMatch && statusMatch) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }

    });

}


/* Calculate report summary */

window.onload = function() {

    var rows =
        document.querySelectorAll("#leaveTable tbody tr.data-row");

    var total = rows.length;
    var approved = 0;
    var pending = 0;

    rows.forEach(function(row) {

        var status =
            row.cells[6].innerText.trim().toLowerCase();

        if (status === "approved") {
            approved++;
        }

        if (status === "pending") {
            pending++;
        }

    });

    document.getElementById("totalLeaves").innerText = total;
    document.getElementById("approvedLeaves").innerText = approved;
    document.getElementById("pendingLeaves").innerText = pending;

};

</script>

</head>

<body>

<!-- Header -->

<div class="header">

    <div class="brand">

        <div class="logo">
            AP
        </div>

        <div>
            <h1>Accenture plc</h1>
            <p>Employee Management Portal</p>
        </div>

    </div>

    <a href="dashboard.jsp" class="dashboard-btn">
        ← Dashboard
    </a>

</div>


<div class="container">

    <!-- Page Title -->

    <div class="page-title">

        <div class="title-left">

            <div class="title-icon">
                📅
            </div>

            <div>
                <h2>Leave Report</h2>
                <p>View and manage employee leave records</p>
            </div>

        </div>

    </div>


    <!-- Summary -->

    <div class="summary">

        <div class="summary-card">

            <div class="summary-icon">
                📋
            </div>

            <div>
                <h3 id="totalLeaves">0</h3>
                <p>Total Leave Applications</p>
            </div>

        </div>


        <div class="summary-card">

            <div class="summary-icon">
                ✓
            </div>

            <div>
                <h3 id="approvedLeaves">0</h3>
                <p>Approved Leaves</p>
            </div>

        </div>


        <div class="summary-card">

            <div class="summary-icon">
                ⏳
            </div>

            <div>
                <h3 id="pendingLeaves">0</h3>
                <p>Pending Leaves</p>
            </div>

        </div>

    </div>


    <!-- Search and Filter -->

    <div class="controls">

        <input
            type="text"
            id="searchEmployee"
            class="search-box"
            placeholder="🔍 Search by Employee ID..."
            onkeyup="filterLeaveReport()">

        <select
            id="statusFilter"
            class="filter-box"
            onchange="filterLeaveReport()">

            <option value="all">All Status</option>
            <option value="approved">Approved</option>
            <option value="pending">Pending</option>
            <option value="rejected">Rejected</option>

        </select>

    </div>


    <!-- Report Table -->

    <div class="table-container">

        <table id="leaveTable">

            <thead>

                <tr>

                    <th>Leave ID</th>
                    <th>Employee ID</th>
                    <th>Leave Type</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Status</th>

                </tr>

            </thead>

            <tbody>

<%
ArrayList<Leave> list =
    (ArrayList<Leave>) request.getAttribute("leaveList");

if (list != null && !list.isEmpty()) {

    for (Leave l : list) {
%>

                <tr class="data-row">

                    <td>
                        <%=l.getLeaveId()%>
                    </td>

                    <td>
                        <%=l.getEmpId()%>
                    </td>

                    <td>
                        <span class="leave-type">
                            <%=l.getLeaveType()%>
                        </span>
                    </td>

                    <td>
                        <%=l.getFromDate()%>
                    </td>

                    <td>
                        <%=l.getToDate()%>
                    </td>

                    <td class="reason">
                        <%=l.getReason()%>
                    </td>

                    <td>

<%
String status = l.getStatus();

if (status != null &&
    status.equalsIgnoreCase("Approved")) {
%>

                        <span class="status status-approved">
                            Approved
                        </span>

<%
} else if (status != null &&
           status.equalsIgnoreCase("Pending")) {
%>

                        <span class="status status-pending">
                            Pending
                        </span>

<%
} else if (status != null &&
           status.equalsIgnoreCase("Rejected")) {
%>

                        <span class="status status-rejected">
                            Rejected
                        </span>

<%
} else {
%>

                        <span class="status status-default">
                            <%=status%>
                        </span>

<%
}
%>

                    </td>

                </tr>

<%
    }

} else {
%>

                <tr>

                    <td colspan="7" class="no-data">

                        <span class="no-data-icon">
                            📭
                        </span>

                        No leave records found.

                    </td>

                </tr>

<%
}
%>

            </tbody>

        </table>

    </div>

</div>


<div class="footer">
    Employee Management Portal • Leave Management
</div>

</body>

</html>