<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Accenture - Employee Management Portal</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, Helvetica, sans-serif;
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #0a3d91, #1565c0, #42a5f5);
        color: #ffffff;
    }

    .redirect-container {
        width: 420px;
        max-width: 90%;
        padding: 45px 35px;
        text-align: center;
        background: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.25);
        border-radius: 20px;
        box-shadow: 0 20px 45px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(12px);
    }

    .logo {
        width: 75px;
        height: 75px;
        margin: 0 auto 20px;
        border-radius: 18px;
        background: #ffffff;
        color: #0d47a1;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 30px;
        font-weight: bold;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    }

    h1 {
        font-size: 26px;
        margin-bottom: 8px;
    }

    .subtitle {
        font-size: 14px;
        opacity: 0.9;
        margin-bottom: 28px;
    }

    .loader {
        width: 45px;
        height: 45px;
        margin: 0 auto 20px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top: 4px solid #ffffff;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    .message {
        font-size: 15px;
        font-weight: 500;
    }

    .login-link {
        display: inline-block;
        margin-top: 22px;
        padding: 10px 22px;
        background: #ffffff;
        color: #0d47a1;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        transition: 0.3s;
    }

    .login-link:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 18px rgba(0, 0, 0, 0.2);
    }

    @keyframes spin {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }

    @media (max-width: 500px) {
        .redirect-container {
            padding: 35px 25px;
        }

        h1 {
            font-size: 22px;
        }
    }
</style>

<script>
    window.onload = function() {
        // Keep the existing JSP redirect functionality
        window.location.href = "login.jsp";
    };
</script>

</head>

<body>

<%
    response.sendRedirect("login.jsp");
%>

<div class="redirect-container">

    <div class="logo">
        AP
    </div>

    <h1>Accenture plc</h1>

    <div class="subtitle">
        Employee Management Portal
    </div>

    <div class="loader"></div>

    <div class="message">
        Redirecting you to the login page...
    </div>

    <a href="login.jsp" class="login-link">
        Go to Login
    </a>

</div>

</body>
</html>