package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.SalaryDAO;
import model.Salary;

@WebServlet("/SalaryServlet")
public class SalaryServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int empId = Integer.parseInt(request.getParameter("empId"));
        String month = request.getParameter("month");

        double basic = Double.parseDouble(request.getParameter("basic"));

        double hra = basic * 0.20;
        double da = basic * 0.10;
        double pf = basic * 0.12;
        double tax = basic * 0.05;

        double netSalary = basic + hra + da - pf - tax;

        Salary salary = new Salary();

        salary.setEmpId(empId);
        salary.setMonth(month);
        salary.setBasic(basic);
        salary.setHra(hra);
        salary.setDa(da);
        salary.setPf(pf);
        salary.setTax(tax);
        salary.setNetSalary(netSalary);

        SalaryDAO dao = new SalaryDAO();

        if (dao.addSalary(salary)) {

        	response.sendRedirect("SalaryReportServlet");

        } else {

            response.getWriter().println("Salary Not Generated");

        }
    }
}