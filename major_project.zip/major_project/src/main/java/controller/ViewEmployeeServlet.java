package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.EmployeeDAO;
import model.Employee;

@WebServlet("/ViewEmployeeServlet")
public class ViewEmployeeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        EmployeeDAO dao = new EmployeeDAO();

        ArrayList<Employee> list = dao.getAllEmployees();

        request.setAttribute("list", list);

        request.getRequestDispatcher("viewEmployee.jsp")
               .forward(request, response);

    }

}