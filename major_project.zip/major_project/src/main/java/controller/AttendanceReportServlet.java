package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.AttendanceDAO;
import model.Attendance;

@WebServlet("/AttendanceReportServlet")
public class AttendanceReportServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        AttendanceDAO dao = new AttendanceDAO();

        ArrayList<Attendance> list =
                dao.getAllAttendance();

        request.setAttribute("attendanceList", list);

        request.getRequestDispatcher("attendanceReport.jsp")
                .forward(request, response);

    }
}