package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.SalaryDAO;
import model.Salary;

@WebServlet("/SalaryReportServlet")
public class SalaryReportServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        SalaryDAO dao = new SalaryDAO();

        ArrayList<Salary> list = dao.getAllSalary();

        request.setAttribute("salaryList", list);

        request.getRequestDispatcher("salaryReport.jsp")
               .forward(request, response);

    }

}