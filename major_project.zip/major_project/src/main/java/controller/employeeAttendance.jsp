<%@ page language="java"
    contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.sql.ResultSet" %>

<%

ResultSet attendance =
    (ResultSet) request.getAttribute("attendance");

%>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>My Attendance</title>

<style>

body {

    font-family: Arial;

    margin: 0;

    padding: 40px;

    background: linear-gradient(
        135deg,
        #141e30,
        #243b55
    );
}

.container {

    background: white;

    padding: 30px;

    border-radius: 20px;

    max-width: 900px;

    margin: auto;
}

h1 {

    text-align: center;

    color: #243b55;
}

table {

    width: 100%;

    border-collapse: collapse;

    margin-top: 30px;
}

th {

    background: #243b55;

    color: white;

    padding: 14px;
}

td {

    padding: 13px;

    text-align: center;

    border-bottom: 1px solid #ddd;
}

.back {

    display: inline-block;

    margin-top: 25px;

    padding: 12px 20px;

    background: #0072ff;

    color: white;

    text-decoration: none;

    border-radius: 8px;
}

</style>

</head>

<body>

<div class="container">

<h1>📅 My Attendance</h1>

<table>

<tr>

<th>Date</th>

<th>Status</th>

</tr>

<%

while(attendance != null &&
      attendance.next()) {

%>

<tr>

<td>
<%= attendance.getDate("attendance_date") %>
</td>

<td>
<%= attendance.getString("status") %>
</td>

</tr>

<%

}

%>

</table>

<a href="dashboard.jsp" class="back">
⬅ Back to Dashboard
</a>

</div>

</body>

</html>