package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.EmployeeDAO;
import model.Employee;

@WebServlet("/UpdateEmployeeServlet")
public class UpdateEmployeeServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        Employee e = new Employee();

        e.setEmpId(Integer.parseInt(request.getParameter("id")));
        e.setName(request.getParameter("name"));
        e.setGender(request.getParameter("gender"));
        e.setEmail(request.getParameter("email"));
        e.setMobile(request.getParameter("mobile"));
        e.setDepartment(request.getParameter("department"));
        e.setDesignation(request.getParameter("designation"));
        e.setBasicSalary(Double.parseDouble(request.getParameter("salary")));
        e.setJoiningDate(request.getParameter("joiningDate"));

        EmployeeDAO dao = new EmployeeDAO();

        if (dao.updateEmployee(e)) {

            response.sendRedirect("ViewEmployeeServlet");

        } else {

            response.getWriter().println("Update Failed.");

        }

    }

}