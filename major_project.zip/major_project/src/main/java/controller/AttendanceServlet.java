package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.AttendanceDAO;
import model.Attendance;

@WebServlet("/AttendanceServlet")
public class AttendanceServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        Attendance attendance = new Attendance();

        attendance.setEmpId(
                Integer.parseInt(request.getParameter("empId")));

        attendance.setAttendanceDate(
                request.getParameter("date"));

        attendance.setStatus(
                request.getParameter("status"));

        AttendanceDAO dao = new AttendanceDAO();

        if (dao.markAttendance(attendance)) {

            response.sendRedirect("AttendanceReportServlet");

        } else {

            response.getWriter().println("Attendance Not Saved");

        }

    }
}