package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LoginDAO;

@WebServlet("/LoginServlet")
public class Loginservlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        LoginDAO dao = new LoginDAO();

        if (dao.validate(username, password)) {

            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            if ("admin".equals(username)) {
                session.setAttribute("role", "admin");
            } else {
                session.setAttribute("role", "employee");
            }

            response.sendRedirect(
                request.getContextPath() + "/dashboard.jsp"
            );

        } else {
            response.sendRedirect(
                request.getContextPath() + "/login.jsp?error=invalid"
            );
        }
    }
}