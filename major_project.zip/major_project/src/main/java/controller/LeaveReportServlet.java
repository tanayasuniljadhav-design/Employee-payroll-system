package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.LeaveDAO;
import model.Leave;

@WebServlet("/LeaveReportServlet")
public class LeaveReportServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        LeaveDAO dao=new LeaveDAO();

        ArrayList<Leave> list=dao.getAllLeave();

        request.setAttribute("leaveList",list);

        request.getRequestDispatcher("leaveReport.jsp")
               .forward(request,response);

    }

}