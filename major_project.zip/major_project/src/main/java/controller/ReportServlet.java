package controller;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.DashboardDAO;

@WebServlet("/ReportServlet")
public class ReportServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        DashboardDAO dao = new DashboardDAO();

        request.setAttribute("employeeCount",
                dao.totalEmployees());

        request.setAttribute("presentCount",
                dao.totalPresentEmployees());

        request.setAttribute("salaryPaid",
                dao.totalSalaryPaid());

        request.setAttribute("leaveCount",
                dao.totalLeaves());

        request.getRequestDispatcher("report.jsp")
                .forward(request, response);

    }

}