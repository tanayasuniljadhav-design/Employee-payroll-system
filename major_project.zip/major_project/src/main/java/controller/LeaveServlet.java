package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.DBConnection;
import dao.LeaveDAO;
import model.Leave;

@WebServlet("/LeaveServlet")
public class LeaveServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        Leave leave = new Leave();

        leave.setEmpId(
                Integer.parseInt(request.getParameter("empId")));

        leave.setLeaveType(
                request.getParameter("leaveType"));

        leave.setFromDate(
                request.getParameter("fromDate"));

        leave.setToDate(
                request.getParameter("toDate"));

        leave.setReason(
                request.getParameter("reason"));

        leave.setStatus("Pending");

        LeaveDAO dao = new LeaveDAO();

        if (dao.applyLeave(leave)) {

            response.sendRedirect("LeaveReportServlet");

        } else {

            response.getWriter().println("Leave Application Failed");

        }

    }

    public boolean approveLeave(int leaveId){

        boolean status=false;

        try{

            Connection con=DBConnection.getConnection();

            PreparedStatement ps=con.prepareStatement(

            "UPDATE leave_details SET status='Approved' WHERE leave_id=?");

            ps.setInt(1,leaveId);

            status=ps.executeUpdate()>0;

        }catch(Exception e){

            e.printStackTrace();

        }

        return status;

    }
    
    public boolean rejectLeave(int leaveId){

        boolean status=false;

        try{

            Connection con=DBConnection.getConnection();

            PreparedStatement ps=con.prepareStatement(

            "UPDATE leave_details SET status='Rejected' WHERE leave_id=?");

            ps.setInt(1,leaveId);

            status=ps.executeUpdate()>0;

        }catch(Exception e){

            e.printStackTrace();

        }

        return status;

    }
}