package controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EmployeeSideDAO;
import model.Employee;

@WebServlet("/EmployeeLeaveServlet")
public class EmployeeLeaveServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String username =
            (String) session.getAttribute("username");

        String role =
            (String) session.getAttribute("role");

        if (username == null || !"employee".equals(role)) {

            response.sendRedirect("login.jsp");

            return;
        }

        EmployeeSideDAO dao =
            new EmployeeSideDAO();

        Employee employee =
            dao.getEmployeeByUsername(username);

        if(employee == null) {

            response.sendRedirect("login.jsp");

            return;
        }

        ResultSet leaves =
            dao.getEmployeeLeaves(
                employee.getEmpId()
            );

        request.setAttribute("leaves", leaves);

        request.getRequestDispatcher(
            "employeeLeave.jsp"
        ).forward(request, response);
    }
}