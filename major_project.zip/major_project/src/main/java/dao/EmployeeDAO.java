package dao;

import java.sql.*;
import java.util.ArrayList;
import model.Employee;

public class EmployeeDAO {

    // Add Employee
    public boolean addEmployee(Employee e) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO employees(name,gender,email,mobile,department,designation,basic_salary,joining_date) VALUES(?,?,?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, e.getName());
            ps.setString(2, e.getGender());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getMobile());
            ps.setString(5, e.getDepartment());
            ps.setString(6, e.getDesignation());
            ps.setDouble(7, e.getBasicSalary());
            ps.setString(8, e.getJoiningDate());

            status = ps.executeUpdate() > 0;

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    // View All Employees
    public ArrayList<Employee> getAllEmployees() {

        ArrayList<Employee> list = new ArrayList<>();

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement("SELECT * FROM employees");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Employee e = new Employee();

                e.setEmpId(rs.getInt("emp_id"));
                e.setName(rs.getString("name"));
                e.setGender(rs.getString("gender"));
                e.setEmail(rs.getString("email"));
                e.setMobile(rs.getString("mobile"));
                e.setDepartment(rs.getString("department"));
                e.setDesignation(rs.getString("designation"));
                e.setBasicSalary(rs.getDouble("basic_salary"));
                e.setJoiningDate(rs.getString("joining_date"));

                list.add(e);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return list;
    }

    // Search Employee
    public Employee getEmployeeById(int id) {

        Employee e = null;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM employees WHERE emp_id=?");

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                e = new Employee();

                e.setEmpId(rs.getInt("emp_id"));
                e.setName(rs.getString("name"));
                e.setGender(rs.getString("gender"));
                e.setEmail(rs.getString("email"));
                e.setMobile(rs.getString("mobile"));
                e.setDepartment(rs.getString("department"));
                e.setDesignation(rs.getString("designation"));
                e.setBasicSalary(rs.getDouble("basic_salary"));
                e.setJoiningDate(rs.getString("joining_date"));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return e;
    }

    // Update Employee
    public boolean updateEmployee(Employee e) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE employees SET name=?,gender=?,email=?,mobile=?,department=?,designation=?,basic_salary=?,joining_date=? WHERE emp_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, e.getName());
            ps.setString(2, e.getGender());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getMobile());
            ps.setString(5, e.getDepartment());
            ps.setString(6, e.getDesignation());
            ps.setDouble(7, e.getBasicSalary());
            ps.setString(8, e.getJoiningDate());
            ps.setInt(9, e.getEmpId());

            status = ps.executeUpdate() > 0;

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }

    // Delete Employee
    public boolean deleteEmployee(int id) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM employees WHERE emp_id=?");

            ps.setInt(1, id);

            status = ps.executeUpdate() > 0;

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return status;
    }
}
