package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Salary;

public class SalaryDAO {

	public ArrayList<Salary> getAllSalary() {

	    ArrayList<Salary> list = new ArrayList<>();

	    try {

	        Connection con = DBConnection.getConnection();

	        PreparedStatement ps =
	        con.prepareStatement("SELECT * FROM salary");

	        ResultSet rs = ps.executeQuery();

	        while(rs.next()){

	            Salary s = new Salary();

	            s.setSalaryId(rs.getInt("salary_id"));
	            s.setEmpId(rs.getInt("emp_id"));
	            s.setMonth(rs.getString("month"));
	            s.setBasic(rs.getDouble("basic"));
	            s.setHra(rs.getDouble("hra"));
	            s.setDa(rs.getDouble("da_amount"));
	            s.setPf(rs.getDouble("pf"));
	            s.setTax(rs.getDouble("tax"));
	            s.setNetSalary(rs.getDouble("net_salary"));

	            list.add(s);

	        }

	    }catch(Exception e){

	        e.printStackTrace();

	    }

	    return list;
	}

	public boolean addSalary(Salary salary) {

	    boolean status = false;

	    try {

	        Connection con = DBConnection.getConnection();

	        String sql = "INSERT INTO salary(emp_id,month,basic,hra,da_amount,pf,tax,net_salary) VALUES(?,?,?,?,?,?,?,?)";

	        PreparedStatement ps = con.prepareStatement(sql);

	        ps.setInt(1, salary.getEmpId());
	        ps.setString(2, salary.getMonth());
	        ps.setDouble(3, salary.getBasic());
	        ps.setDouble(4, salary.getHra());
	        ps.setDouble(5, salary.getDa());
	        ps.setDouble(6, salary.getPf());
	        ps.setDouble(7, salary.getTax());
	        ps.setDouble(8, salary.getNetSalary());

	        int i = ps.executeUpdate();

	        if (i > 0) {
	            status = true;
	        }

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return status;
	}}