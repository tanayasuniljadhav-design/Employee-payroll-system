package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.Employee;

public class EmployeeSideDAO {

    // Get employee profile using username
    public Employee getEmployeeByUsername(String username) {

        Employee employee = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT * FROM employees WHERE username=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                employee = new Employee();

                employee.setEmpId(rs.getInt("emp_id"));
                employee.setName(rs.getString("name"));
                employee.setGender(rs.getString("gender"));
                employee.setEmail(rs.getString("email"));
                employee.setMobile(rs.getString("mobile"));
                employee.setDepartment(rs.getString("department"));
                employee.setDesignation(rs.getString("designation"));
                employee.setBasicSalary(rs.getDouble("basic_salary"));
               
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return employee;
    }


    // Get salary of employee
    public ResultSet getEmployeeSalary(int empId) {

        ResultSet rs = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT * FROM salary WHERE emp_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, empId);

            rs = ps.executeQuery();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return rs;
    }


    // Get attendance of employee
    public ResultSet getEmployeeAttendance(int empId) {

        ResultSet rs = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT * FROM attendance WHERE emp_id=? " +
                "ORDER BY attendance_date DESC";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, empId);

            rs = ps.executeQuery();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return rs;
    }


    // Get leaves of employee
    public ResultSet getEmployeeLeaves(int empId) {

        ResultSet rs = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT * FROM leave_details " +
                "WHERE emp_id=? ORDER BY from_date DESC";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, empId);

            rs = ps.executeQuery();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return rs;
    }
}