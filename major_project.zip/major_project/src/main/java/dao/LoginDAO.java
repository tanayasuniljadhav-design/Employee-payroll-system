package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO {

    public boolean validate(String username, String password) {

        boolean result = false;

        String sql =
                "SELECT * FROM users WHERE username = ? AND password = ?";

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                result = true;

                System.out.println(
                        "LOGIN SUCCESSFUL: " + username
                );

            } else {

                System.out.println(
                        "INVALID LOGIN: " + username
                );
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            System.out.println("LOGIN DATABASE ERROR");
            e.printStackTrace();
        }

        return result;
    }
}