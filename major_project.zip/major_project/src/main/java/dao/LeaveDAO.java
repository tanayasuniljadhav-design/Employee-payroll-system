package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Leave;

public class LeaveDAO {

    public boolean applyLeave(Leave l) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "INSERT INTO leave_details(emp_id,leave_type,from_date,to_date,reason,status) VALUES(?,?,?,?,?,?)");

            ps.setInt(1, l.getEmpId());
            ps.setString(2, l.getLeaveType());
            ps.setString(3, l.getFromDate());
            ps.setString(4, l.getToDate());
            ps.setString(5, l.getReason());
            ps.setString(6, l.getStatus());

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

public ArrayList<Leave> getAllLeave() {

    ArrayList<Leave> list = new ArrayList<>();

    try {

        Connection con = DBConnection.getConnection();

        PreparedStatement ps =
        con.prepareStatement("SELECT * FROM leave_details");

        ResultSet rs = ps.executeQuery();

        while(rs.next()){

            Leave l = new Leave();

            l.setLeaveId(rs.getInt("leave_id"));
            l.setEmpId(rs.getInt("emp_id"));
            l.setLeaveType(rs.getString("leave_type"));
            l.setFromDate(rs.getString("from_date"));
            l.setToDate(rs.getString("to_date"));
            l.setReason(rs.getString("reason"));
            l.setStatus(rs.getString("status"));

            list.add(l);

        }

    }catch(Exception e){

        e.printStackTrace();

    }

    return list;

}}
