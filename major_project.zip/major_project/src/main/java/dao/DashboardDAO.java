package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DashboardDAO {

    public int totalEmployees() {

        int count = 0;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement("SELECT COUNT(*) FROM employees");

            ResultSet rs = ps.executeQuery();

            if (rs.next())
                count = rs.getInt(1);

        } catch (Exception e) {

            e.printStackTrace();

        }

        return count;
    }

    public int totalPresentEmployees() {

        int count = 0;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement("SELECT COUNT(*) FROM attendance WHERE status='Present'");

            ResultSet rs = ps.executeQuery();

            if (rs.next())
                count = rs.getInt(1);

        } catch (Exception e) {

            e.printStackTrace();

        }

        return count;
    }

    public double totalSalaryPaid() {

        double total = 0;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement("SELECT SUM(net_salary) FROM salary");

            ResultSet rs = ps.executeQuery();

            if (rs.next())
                total = rs.getDouble(1);

        } catch (Exception e) {

            e.printStackTrace();

        }

        return total;
    }

    public int totalLeaves() {

        int count = 0;

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement("SELECT COUNT(*) FROM leave_details");

            ResultSet rs = ps.executeQuery();

            if (rs.next())
                count = rs.getInt(1);

        } catch (Exception e) {

            e.printStackTrace();

        }

        return count;
    }

}
