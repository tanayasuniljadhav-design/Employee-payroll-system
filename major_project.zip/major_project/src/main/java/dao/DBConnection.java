package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3307/employee_payroll";

    private static final String USERNAME = "root";

    private static final String PASSWORD = "";

    public static Connection getConnection() throws Exception {

        Class.forName("com.mysql.cj.jdbc.Driver");

        Connection con = DriverManager.getConnection(
                URL,
                USERNAME,
                PASSWORD
        );

        System.out.println("=================================");
        System.out.println("MYSQL DATABASE CONNECTED");
        System.out.println("Database: employee_payroll");
        System.out.println("=================================");

        return con;
    }
}