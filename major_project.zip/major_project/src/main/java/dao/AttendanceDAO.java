package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Attendance;

public class AttendanceDAO {

	public ArrayList<Attendance> getAllAttendance() {

	    ArrayList<Attendance> list = new ArrayList<>();

	    try {

	        Connection con = DBConnection.getConnection();

	        PreparedStatement ps =
	                con.prepareStatement("SELECT * FROM attendance");

	        ResultSet rs = ps.executeQuery();

	        while(rs.next()){

	            Attendance a = new Attendance();

	            a.setAttendanceId(rs.getInt("attendance_id"));
	            a.setEmpId(rs.getInt("emp_id"));
	            a.setAttendanceDate(rs.getString("attendance_date"));
	            a.setStatus(rs.getString("status"));

	            list.add(a);

	        }

	    } catch(Exception e){

	        e.printStackTrace();

	    }

	    return list;

	}

	public boolean markAttendance(Attendance attendance) {

	    boolean status = false;

	    try {

	        Connection con = DBConnection.getConnection();

	        String sql = "INSERT INTO attendance(emp_id, attendance_date, status) VALUES(?,?,?)";

	        PreparedStatement ps = con.prepareStatement(sql);

	        ps.setInt(1, attendance.getEmpId());
	        ps.setString(2, attendance.getAttendanceDate());
	        ps.setString(3, attendance.getStatus());

	        int i = ps.executeUpdate();

	        if (i > 0) {
	            status = true;
	        }

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	    return status;
	}}