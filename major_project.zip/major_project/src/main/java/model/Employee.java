package model;

import java.io.Serializable;

public class Employee implements Serializable {

    private int empId;
    private String name;
    private String gender;
    private String email;
    private String mobile;
    private String department;
    private String designation;
    private double basicSalary;
    private String joiningDate;

    public Employee() {
    }

    public Employee(int empId, String name, String gender, String email,
                    String mobile, String department,
                    String designation, double basicSalary,
                    String joiningDate) {

        this.empId = empId;
        this.name = name;
        this.gender = gender;
        this.email = email;
        this.mobile = mobile;
        this.department = department;
        this.designation = designation;
        this.basicSalary = basicSalary;
        this.joiningDate = joiningDate;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    @Override
    public String toString() {
        return "Employee [empId=" + empId +
                ", name=" + name +
                ", gender=" + gender +
                ", email=" + email +
                ", mobile=" + mobile +
                ", department=" + department +
                ", designation=" + designation +
                ", basicSalary=" + basicSalary +
                ", joiningDate=" + joiningDate + "]";
    }
}
