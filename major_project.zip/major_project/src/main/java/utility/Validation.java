package utility;

public class Validation {

    public static boolean isEmailValid(String email){

        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");

    }

    public static boolean isMobileValid(String mobile){

        return mobile.matches("[0-9]{10}");

    }

    public static boolean isEmpty(String value){

        return value==null || value.trim().equals("");

    }

}
